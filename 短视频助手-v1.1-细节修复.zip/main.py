"""
main.py — 短视频助手 主程序 (Flet GUI)
"""
import flet as ft
import json, os, threading, copy, re
from pathlib import Path
import translator as tr
import assist_api
from assist_api import _callbacks, api_log as _api_log

# ──────────────────────────────────────────────────────────
#  开发者模式日志（本地维护，开发者控制台用）
# ──────────────────────────────────────────────────────────
_page_ref: list = []                    # [ft.Page] 主页面引用（main()中填充）
_dev_log_lines: list[str] = []           # 本地日志缓存
_dev_console_open: list[bool] = [False]  # 控制台开关标记
_dev_console_cb: list = [None]           # [ft.Checkbox] 开发者勾选框引用
_dev_log_ref: list = []                  # [ft.Text] 控制台文字引用
_status_lbl_ref: list = []               # [ft.Text] 状态栏文字引用
_dev_log_count = 0                       # 用于给状态栏去重闪烁

def _dev_log(msg: str):
    """写开发者日志面板 + API日志缓冲（两边都写）"""
    import datetime as _dt
    # 同时写 assist_api 的日志缓冲（供 API 读取）
    try:
        _api_log(msg)
    except Exception:
        pass
    ts = _dt.datetime.now().strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    _dev_log_lines.append(line)
    if len(_dev_log_lines) > 300:
        _dev_log_lines[:] = _dev_log_lines[-300:]
    print(msg)  # 同时写到 stdout（API 日志）
    # 更新状态栏（跨线程安全：通过 run_task）
    if _status_lbl_ref:
        def _set_status():
            _status_lbl_ref[0].value = line
            _status_lbl_ref[0].color = ft.Colors.YELLOW_200
            try:
                _status_lbl_ref[0].update()
            except Exception:
                pass
            def _reset():
                _status_lbl_ref[0].color = ft.Colors.WHITE54
                try:
                    _status_lbl_ref[0].update()
                except Exception:
                    pass
                # 5秒后淡出
                def _fade():
                    _status_lbl_ref[0].value = "⬢ 就绪"
                    _status_lbl_ref[0].color = ft.Colors.WHITE38
                    try:
                        _status_lbl_ref[0].update()
                    except Exception:
                        pass
                threading.Timer(5, _fade).start()
            threading.Timer(3, _reset).start()
        # 尝试从当前 page 更新（如果可用）
        if _page_ref:
            async def _async_set_status(_=None):
                _set_status()
            _page_ref[0].run_task(_async_set_status)
    # 调度开发者控制台刷新
    if _page_ref:
        _page_ref[0].run_task(_refresh_dev_log)
        _page_ref[0].run_task(_run_console_update)

# ──────────────────────────────────────────────────────────
#  路径
# ──────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
PRESETS_FILE = DATA_DIR / "presets.json"
SETTINGS_FILE = DATA_DIR / "settings.json"
DATA_DIR.mkdir(exist_ok=True)


def load_json(path: Path, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default or {}


def save_json(path: Path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


# ──────────────────────────────────────────────────────────
#  平台配置
# ──────────────────────────────────────────────────────────
PLATFORMS = {
    "xiaohongshu": {"label": "📕 小红书", "max_tags": 50, "color": ft.Colors.RED_400},
    "douyin":      {"label": "🎵 抖音",   "max_tags": 5,  "color": ft.Colors.BLACK},
    "kuaishou":    {"label": "⚡ 快手",   "max_tags": 4,  "color": ft.Colors.ORANGE_400},
    "dewu":        {"label": "🌿 得物",   "max_tags": 5,  "color": ft.Colors.GREEN_400},
}
LANGS = ["zh", "en", "ja", "ko"]
LANG_LABELS = {"zh": "🇨🇳 中文", "en": "🇺🇸 英文", "ja": "🇯🇵 日文", "ko": "🇰🇷 韩文"}
TAG_CATEGORIES = ["游戏", "角色", "平台活动", "通用"]


# ──────────────────────────────────────────────────────────
#  主应用
# ──────────────────────────────────────────────────────────
def main(page: ft.Page):
    page.title = "短视频助手 ✨"
    page.window_width = 1400
    page.window_height = 950
    page.window_min_width = 1100
    page.scroll = ft.ScrollMode.AUTO
    page.theme_mode = ft.ThemeMode.DARK
    page.padding = 0

    # ── 加载数据 ──
    presets = load_json(PRESETS_FILE, {})
    settings = load_json(SETTINGS_FILE, {})

    # ── 恢复开发者模式状态 ──
    _dev_console_open[0] = settings.get("dev_console_open", False)

    # ── 全局状态 ──
    titles: dict[str, dict[str, ft.TextField]] = {}
    tag_fields: dict[str, ft.TextField] = {}          # 平台Tab 控件（当前活跃）
    assistant_tag_fields: dict[str, ft.TextField] = {}  # 助手Tab 专用控件
    tag_count_labels: dict[str, ft.Text] = {}
    tag_chip_containers: dict[str, ft.Ref[ft.Container]] = {}
    current_tab = ["assistant"]  # 用列表包裹，使其可在闭包里被修改

    translate_lock = threading.Lock()

    # ── 历史记录管理 ──
    def get_char_history() -> list[str]:
        return presets.get("char_history", [])[:20]  # 最多保留20条

    def add_char_history(name: str):
        if not name.strip():
            return
        history = get_char_history()
        if name in history:
            history.remove(name)
        history.insert(0, name)
        presets["char_history"] = history[:20]
        save_json(PRESETS_FILE, presets)

    def get_theme_history() -> list[str]:
        return presets.get("theme_history", [])[:20]

    def add_theme_history(name: str):
        if not name.strip():
            return
        history = get_theme_history()
        if name in history:
            history.remove(name)
        history.insert(0, name)
        presets["theme_history"] = history[:20]
        save_json(PRESETS_FILE, presets)

    # ── 预设管理 ──
    def get_combo_presets() -> list[dict]:
        return presets.get("combo_presets", [])

    def get_activity_tag_presets(platform: str) -> list:
        return presets.get("activity_tag_presets", {}).get(platform, [])

    def save_activity_tag_preset(platform: str, name: str, tags: list[str]):
        """保存活动Tag预设"""
        presets.setdefault("activity_tag_presets", {}).setdefault(platform, [])
        act_presets = presets["activity_tag_presets"][platform]
        # 更新同名或新增
        for i, p in enumerate(act_presets):
            if p.get("name") == name:
                act_presets[i] = {"name": name, "tags": tags}
                save_json(PRESETS_FILE, presets)
                return
        act_presets.insert(0, {"name": name, "tags": tags})
        presets["activity_tag_presets"][platform] = act_presets[:20]  # 最多20条
        save_json(PRESETS_FILE, presets)

    def get_fill_tag_presets(platform: str) -> list:
        """获取填充Tag预设（普通标签预设）"""
        return presets.get("fill_tag_presets", {}).get(platform, [])

    def save_fill_tag_preset(platform: str, name: str, tags: list[str]):
        """保存填充Tag预设（普通标签预设）"""
        presets.setdefault("fill_tag_presets", {}).setdefault(platform, [])
        fill_presets = presets["fill_tag_presets"][platform]
        # 更新同名或新增
        for i, p in enumerate(fill_presets):
            if p.get("name") == name:
                fill_presets[i] = {"name": name, "tags": tags}
                save_json(PRESETS_FILE, presets)
                return
        fill_presets.insert(0, {"name": name, "tags": tags})
        presets["fill_tag_presets"][platform] = fill_presets[:20]  # 最多20条
        save_json(PRESETS_FILE, presets)

    def save_combo_preset(name: str, char: str, theme: str, result: str):
        """保存组合预设"""
        combo = {
            "name": name,
            "char": char,
            "theme": theme,
            "result": result,
        }
        combos = get_combo_presets()
        # 更新同名或新增
        for i, c in enumerate(combos):
            if c.get("name") == name:
                combos[i] = combo
                break
        else:
            combos.insert(0, combo)
        presets["combo_presets"] = combos[:50]  # 最多50条
        save_json(PRESETS_FILE, presets)

    # ──────────────────────────────────────────────────────
    #  角色翻译预设
    # ──────────────────────────────────────────────────────
    def get_char_translations() -> dict:
        """获取角色翻译预设字典 {角色名: {en, ja, ko}}"""
        return presets.get("char_translations", {})

    def get_char_translation(char: str) -> dict | None:
        """获取单个角色的翻译预设"""
        translations = get_char_translations()
        return translations.get(char)

    def save_char_translation(char: str, en: str = "", ja: str = "", ko: str = ""):
        """保存角色翻译预设"""
        translations = get_char_translations()
        translations[char] = {"en": en, "ja": ja, "ko": ko}
        presets["char_translations"] = translations
        save_json(PRESETS_FILE, presets)

    def delete_char_translation(char: str):
        """删除角色翻译预设"""
        translations = get_char_translations()
        if char in translations:
            del translations[char]
            presets["char_translations"] = translations
            save_json(PRESETS_FILE, presets)

    # ──────────────────────────────────────────────────────
    #  工具函数
    # ──────────────────────────────────────────────────────
    def get_api_keys():
        return settings.get("api_keys", {})

    def get_selected_api():
        return selected_api_dd.value or "deep_translator_google"

    def get_all_tags() -> list[str]:
        all_tags = []
        for cat in TAG_CATEGORIES:
            all_tags.extend(presets.get("tags", {}).get(cat, []))
        return list(dict.fromkeys(all_tags))

    def suggest_tags(keyword: str) -> list[str]:
        all_tags = get_all_tags()
        kw = keyword.lower()
        return [t for t in all_tags if kw in t.lower()][:20]

    def parse_tags(raw: str) -> list[str]:
        """只提取 # 开头的 tag，过滤纯文本内容"""
        tags = []
        seen = set()
        for m in re.finditer(r"(?<!\S)#([^\s#,]+)", raw):
            t = m.group(1).strip()
            if t and t.lower() not in seen:
                tags.append(t)
                seen.add(t.lower())
        return tags

    def format_tags(tags: list[str], prefix="#") -> str:
        return " ".join(f"{prefix}{t}" for t in tags if t)

    def dedup_tags(tags: list[str]) -> list[str]:
        """去重，保持顺序"""
        seen = set()
        result = []
        for t in tags:
            t_lower = t.lower()
            if t_lower not in seen:
                seen.add(t_lower)
                result.append(t)
        return result

    def update_tag_count(platform: str):
        tf = tag_fields.get(platform)
        if not tf:
            return
        lbl = tag_count_labels.get(platform)
        if not lbl:
            return
        cnt = len(parse_tags(tf.value or ""))
        max_t = PLATFORMS[platform]["max_tags"]
        lbl.value = f"{cnt}/{max_t}"
        lbl.color = ft.Colors.RED_400 if cnt > max_t else ft.Colors.GREEN_400
        page.update()

    def _replace_chars_with_preset(text: str) -> tuple[str, dict, bool]:
        """
        智能替换文本中的角色名为预设翻译
        返回: (处理后的原文, 翻译结果字典, 是否使用了预设)
        """
        char_translations = get_char_translations()
        if not char_translations:
            return text, {}, False
        
        # 提取文本中的角色名（检查是否包含预设的角色名）
        matched_chars = []
        for char_name in char_translations.keys():
            if char_name in text:
                matched_chars.append(char_name)
        
        if not matched_chars:
            return text, {}, False
        
        # 构建翻译结果（如果有多个角色，取第一个匹配的预设）
        results = {}
        for lang in ["en", "ja", "ko"]:
            # 替换所有匹配的角色名
            trans_text = text
            for char_name in matched_chars:
                char_result = char_translations[char_name].get(lang, "")
                if char_result:
                    trans_text = trans_text.replace(char_name, char_result)
            if trans_text != text:  # 有变化才记录
                results[lang] = trans_text
        
        if results:
            # 用第一个匹配的角色预设替换原文
            char_name = matched_chars[0]
            char_result = char_translations[char_name]
            new_text = text.replace(char_name, char_result.get("en", char_name))
            return new_text, results, True
        return text, {}, False

    async def _do_translate_ui(zh_text: str, platform: str, results: dict, preset_used: bool):
        """[主线程] 执行翻译后的UI写入和提示"""
        try:
            if platform and platform in PLATFORMS:
                tf = assistant_tag_fields.get(platform) or tag_fields.get(platform)
                if tf:
                    targets = ["en", "ja", "ko"]
                    new_lines = [zh_text]
                    for lang in targets:
                        if lang in results and "[翻译失败" not in results[lang]:
                            new_lines.append(results[lang])
                    tf.value = "\n".join(new_lines)
                    tf.update()
                    _refresh_tag_chips(platform)  # 同步刷新 Chip 显示
                    _dev_log(f"[翻译] 已写入 {platform}，Chip已刷新")
            source = "预设" if preset_used else "API"
            en_txt = results.get("en", "N/A")[:30]
            # 用状态栏文字代替 SnackBar（更可靠）
            if _status_lbl_ref:
                _status_lbl_ref[0].value = f"✅ 翻译完成（{source}）EN: {en_txt}"
                _status_lbl_ref[0].color = ft.Colors.GREEN_400
                _status_lbl_ref[0].update()
                import threading as _t
                def _fade_status():
                    if _status_lbl_ref:
                        _status_lbl_ref[0].value = "⬢ 就绪"
                        _status_lbl_ref[0].color = ft.Colors.WHITE38
                        try:
                            _status_lbl_ref[0].update()
                        except Exception:
                            pass
                _t.Timer(4, _fade_status).start()
        except Exception as ex:
            _dev_log(f"[翻译] UI写入异常: {ex}")

    async def _do_translate_fail_ui(ex: str):
        """[主线程] 显示翻译失败提示"""
        try:
            if _status_lbl_ref:
                _status_lbl_ref[0].value = f"❌ 翻译失败: {ex}"
                _status_lbl_ref[0].color = ft.Colors.RED_400
                _status_lbl_ref[0].update()
        except Exception:
            pass

    # ── 通用状态栏提示（替换 SnackBar）───────────────
    import threading as _t_timer
    _fade_timer: list = []

    def _show_status(msg: str, color=ft.Colors.GREEN_400, duration=3.0):
        """在状态栏显示消息，自动淡出"""
        if not _status_lbl_ref:
            return
        def _set():
            try:
                _status_lbl_ref[0].value = msg
                _status_lbl_ref[0].color = color
                _status_lbl_ref[0].update()
            except Exception:
                pass
        if _page_ref:
            async def _async_set(_=None):
                _set()
            _page_ref[0].run_task(_async_set)
        # 延迟淡出
        def _fade():
            try:
                _status_lbl_ref[0].value = "⬢ 就绪"
                _status_lbl_ref[0].color = ft.Colors.WHITE38
                _status_lbl_ref[0].update()
            except Exception:
                pass
        _t_timer.Timer(duration, _fade).start()

    def do_translate(zh_text: str, platform: str = None):
        """翻译中文标题到各语言，并写入对应编辑框"""
        if not zh_text.strip():
            return

        _dev_log(f"[翻译] 原文={zh_text[:50]} 平台={platform}")

        def _do():
            try:
                targets = ["en", "ja", "ko"]
                results = {}
                preset_used = False

                char_translations = get_char_translations()
                _dev_log(f"[翻译] 角色预设={list(char_translations.keys()) if char_translations else '无'}")

                char_part, theme_part = zh_text, ""
                if "の" in zh_text:
                    parts = zh_text.split("の", 1)
                    char_part = parts[0]
                    theme_part = parts[1] if len(parts) > 1 else ""

                preset_char = None
                if char_translations and char_part in char_translations:
                    preset_char = char_part

                if preset_char:
                    char_result = char_translations[preset_char]
                    _dev_log(f"[翻译] 角色预设: {preset_char} -> {char_result}")
                    api = get_selected_api()
                    api_keys = get_api_keys()
                    theme_results = {}
                    if theme_part:
                        _dev_log(f"[翻译] 翻译主题: {theme_part}")
                        theme_results = tr.translate(theme_part, targets, api, api_keys)
                        _dev_log(f"[翻译] 主题API结果={theme_results}")
                    for lang in targets:
                        char_lang = char_result.get(lang, char_result.get("en", preset_char))
                        theme_lang = theme_results.get(lang, "") if theme_results else ""
                        if theme_lang and theme_lang not in ("[翻译失败]", "[Translation failed]"):
                            results[lang] = f"{char_lang}の{theme_lang}"
                        else:
                            results[lang] = char_lang
                    preset_used = True
                    _dev_log(f"[翻译] 预设+API组合翻译: {results}")
                else:
                    api = get_selected_api()
                    api_keys = get_api_keys()
                    _dev_log(f"[翻译] 调用API: {api}")
                    results = tr.translate(zh_text, targets, api, api_keys)
                    _dev_log(f"[翻译] API结果={results}")

                _dev_log(f"[翻译] 最终results={results}, preset_used={preset_used}")
                page.run_task(_do_translate_ui, zh_text, platform, results, preset_used)
            except Exception as ex:
                _dev_log(f"[翻译] 异常: {ex}")
                page.run_task(_do_translate_fail_ui, str(ex))

        threading.Thread(target=_do, daemon=True).start()


    def _refresh_tag_chips(platform: str):
        """全局刷新标签 Chips 显示"""
        tf = assistant_tag_fields.get(platform) or tag_fields.get(platform)
        if not tf:
            return
        tags = parse_tags(tf.value or "")
        cnt_lbl = tag_count_labels.get(platform)
        max_t = PLATFORMS[platform]["max_tags"]
        if cnt_lbl:
            cnt_lbl.value = f"{len(tags)}/{max_t}"
            cnt_lbl.color = ft.Colors.RED_400 if len(tags) > max_t else ft.Colors.GREEN_400
            try:
                cnt_lbl.update()
            except RuntimeError:
                pass
        chip_ref = tag_chip_containers.get(platform)
        if not chip_ref or not chip_ref.current:
            return
        cfg = PLATFORMS[platform]
        color = cfg["color"]
        chips = []
        for tag in tags:
            def _make_del(t):
                def _del(_):
                    tf2 = assistant_tag_fields.get(platform) or tag_fields.get(platform)
                    if not tf2:
                        return
                    import re as _re
                    pattern = _re.compile(rf"(?<![^\s])#{_re.escape(t)}(?!\w)", _re.UNICODE)
                    tf2.value = "\n".join(line for line in pattern.sub("", tf2.value or "").splitlines() if line.strip())
                    _refresh_tag_chips(platform)
                    try:
                        tf2.update()
                    except RuntimeError:
                        pass
                return _del
            chips.append(ft.Chip(
                label=ft.Text(f"#{tag}", size=11),
                on_click=_make_del(tag),
                bgcolor=ft.Colors.with_opacity(0.2, color),
            ))
        row = ft.Row(chips, wrap=True, spacing=4, run_spacing=4) if chips else ft.Text("暂无标签，点击下方快捷按钮添加", size=12, color=ft.Colors.GREY_400)
        chip_ref.current.content = ft.Column([row], spacing=4)
        try:
            chip_ref.current.update()
        except RuntimeError:
            pass




    def do_auto_tags(platform: str, base_tags: list[str] = None):
        """自动补全 Tag：先用 default_tags，不足 max_tags 时从全局 Tag 库继续补充"""
        # 中英文兼容：PLATFORMS 用英文 key，API 传入中文
        plat_key = platform
        if plat_key not in assistant_tag_fields and plat_key not in tag_fields:
            for eng_key, cfg in PLATFORMS.items():
                if plat_key in cfg.get("label", ""):
                    plat_key = eng_key
                    break
        max_t = PLATFORMS[plat_key]["max_tags"]
        if base_tags is None:
            base_tags = presets.get("platform_defaults", {}).get(platform, {}).get("default_tags", [])
        # 优先从 assistant_tag_fields 取（助手Tab），其次 tag_fields（平台Tab）
        tf = assistant_tag_fields.get(plat_key) or tag_fields.get(plat_key)
        if not tf:
            _dev_log(f"[自动Tag] {plat_key} 无控件，assistant={bool(assistant_tag_fields.get(plat_key))} tag_fields={bool(tag_fields.get(plat_key))}")
            return
        cur = tf.value or ""
        existing = parse_tags(cur)
        merged = dedup_tags(existing + base_tags)
        # 不足上限时，从全局 tag 库按顺序补充
        if len(merged) < max_t:
            pool = get_all_tags()
            merged_set = {t.lower() for t in merged}
            for t in pool:
                if len(merged) >= max_t:
                    break
                if t.lower() not in merged_set:
                    merged.append(t)
                    merged_set.add(t.lower())
        lines = cur.splitlines()
        # 保留所有非 # 行（中文标题 + 翻译的 EN/JA/KO 等），只去掉 #标签行
        title_lines = [l for l in lines if l.strip() and not l.strip().startswith("#")]
        tf.value = ("\n".join(title_lines) + "\n" + " ".join(f"#{t}" for t in merged)).strip()
        _refresh_tag_chips(plat_key)
        try:
            tf.update()
            _dev_log(f"[自动Tag] {plat_key} 成功，共 {len(merged)} 个tag")
        except RuntimeError as ex:
            _dev_log(f"[自动Tag] {plat_key} update异常(RuntimeError): {ex}")


    def add_activity_tags(platform: str, activity_tags: list[str]):
        """填入活动Tag（优先排在第一位，去重）"""
        # 中英文兼容：PLATFORMS 用英文 key（如 xiaohongshu），API 传入中文（如 小红书）
        plat_key = platform
        _dev_log(f"[活动Tag-DEBUG] add_activity_tags: platform={platform}, activity_tags={activity_tags}")
        _dev_log(f"[活动Tag-DEBUG] assistant_tag_fields keys={list(assistant_tag_fields.keys())}")
        _dev_log(f"[活动Tag-DEBUG] tag_fields keys={list(tag_fields.keys())}")
        if plat_key not in assistant_tag_fields and plat_key not in tag_fields:
            # 从 PLATFORMS 的 label 字段找中文名对应的英文 key
            for eng_key, cfg in PLATFORMS.items():
                if plat_key in cfg.get("label", ""):
                    plat_key = eng_key
                    break
        tf = assistant_tag_fields.get(plat_key) or tag_fields.get(plat_key)
        if not tf:
            _dev_log(f"[活动Tag] {platform}({plat_key}) 无控件，无法填入")
            return
        cur = tf.value or ""
        existing = parse_tags(cur)
        # 活动Tag排在最前，去掉 existing 中与活动Tag重复的部分，再拼接
        act_dedup = dedup_tags(activity_tags)
        act_set = {t.lower() for t in act_dedup}
        rest = [t for t in existing if t.lower() not in act_set]
        max_tags = PLATFORMS[plat_key]["max_tags"] if plat_key in PLATFORMS else 20
        final_tags = (act_dedup + rest)[:max_tags]
        lines = cur.splitlines()
        title_lines = [l for l in lines if l.strip() and not l.strip().startswith("#")]
        tf.value = ("\n".join(title_lines) + "\n" + " ".join(f"#{t}" for t in final_tags)).strip()
        _refresh_tag_chips(plat_key)
        try:
            tf.update()
            _dev_log(f"[活动Tag] {platform} 写入 {len(act_dedup)} 个活动tag（排在首位）")
        except RuntimeError as ex:
            _dev_log(f"[活动Tag] {platform} update异常: {ex}")

    async def _do_auto_tags(platform: str):
        """异步版：自动填充 Tag"""
        if not assistant_tag_fields:
            try:
                build_assistant_tab()
            except Exception as ex:
                _dev_log(f"[自动Tag] 懒初始化失败: {ex}")
                return
        do_auto_tags(platform)
        if _page_ref:
            _page_ref[0].update()

    async def _do_add_activity_tags(platform: str, activity_tags: list[str]):
        """异步版：API 回调调度到主线程"""
        if not assistant_tag_fields:
            try:
                build_assistant_tab()
            except Exception as ex:
                _dev_log(f"[活动Tag] 懒初始化失败: {ex}")
                return
        add_activity_tags(platform, activity_tags)
        do_auto_tags(platform)  # 自动填充补满剩余槽位
        if _page_ref:
            _page_ref[0].update()

    def _set_activity_tags(platform: str, activity_tags: list[str]):
        """API：填入活动Tag（调度到主线程）"""
        if _page_ref:
            _page_ref[0].run_task(_do_add_activity_tags, platform, activity_tags)
        else:
            _dev_log("[活动Tag] _page_ref 为空，无法调度！")

    # ──────────────────────────────────────────────────────
    #  协助 API 回调注册
    # ──────────────────────────────────────────────────────
    def _extract_title(text: str) -> str:
        for line in text.splitlines():
            if line.strip() and not line.strip().startswith("#"):
                return line.strip()
        return ""

    def _replace_title(text: str, new_title: str) -> str:
        lines = text.splitlines()
        for i, line in enumerate(lines):
            if line.strip() and not line.strip().startswith("#"):
                lines[i] = new_title
                return "\n".join(lines)
        return new_title + ("\n" + "\n".join(lines) if lines else "")

    def _get_state():
        state = {}
        for plat in PLATFORMS:
            tf = tag_fields.get(plat)
            content = tf.value or "" if tf else ""
            state[plat] = {
                "title": _extract_title(content),
                "tags": parse_tags(content),
            }
        return state

    def _update_tags(platform, tags):
        tf = assistant_tag_fields.get(platform) or tag_fields.get(platform)
        if not tf:
            return
        cur = tf.value or ""
        title_line = _extract_title(cur)
        max_t = PLATFORMS[platform]["max_tags"]
        tag_str = " ".join(f"#{t}" for t in tags[:max_t])
        tf.value = (title_line + "\n" + tag_str).strip()
        _refresh_tag_chips(platform)
        try:
            tf.update()
        except RuntimeError:
            pass

    def _update_title(platform, lang, text):
        tf = assistant_tag_fields.get(platform) or tag_fields.get(platform)
        if not tf:
            return
        # 写入新标题，清除所有旧tag行（避免和后续 _update_tags 叠加导致多1个）
        cur = tf.value or ""
        non_tag_lines = [l for l in cur.splitlines() if l.strip().startswith("#")]
        tf.value = text  # 只写标题，不保留旧tag行
        try:
            tf.update()
        except RuntimeError:
            pass

    # ──────────────────────────────────────────────────────
    #  上次输入持久化（供 combo 输入框 & 启动恢复）
    # ──────────────────────────────────────────────────────
    _last = settings.get("last_input", {})

    def _save_last_char(val: str):
        settings.setdefault("last_input", {})["last_char"] = val
        save_json(SETTINGS_FILE, settings)

    def _save_last_theme(val: str):
        settings.setdefault("last_input", {})["last_theme"] = val
        save_json(SETTINGS_FILE, settings)

    def _save_last_activity(plat: str, val: str):
        settings.setdefault("last_input", {}).setdefault("activity", {})[plat] = val
        save_json(SETTINGS_FILE, settings)

    def _add_activity_history(tag_str: str):
        """把活动标签输入加入历史"""
        tag_str = tag_str.strip()
        if not tag_str:
            return
        history = presets.get("activity_history", [])
        # 去重：删除旧的，插入到最前
        history = [h for h in history if h != tag_str]
        history.insert(0, tag_str)
        presets["activity_history"] = history[:20]
        save_json(PRESETS_FILE, presets)

    def _get_activity_history() -> list[str]:
        return presets.get("activity_history", [])[:20]

    assist_api.register("get_state", _get_state)
    assist_api.register("update_tags", _update_tags)
    assist_api.register("update_title", _update_title)
    assist_api.register("suggest_tags", suggest_tags)

    # ──────────────────────────────────────────────────────
    #  全局引用（供 API 读写 combo 输入框）
    # ──────────────────────────────────────────────────────
    _page_ref: list = []            # [ft.Page]  主页面引用，供 API 回调调度 UI 更新
    _combo_char_tf_ref: list = []   # [ft.TextField]
    _combo_theme_tf_ref: list = []  # [ft.TextField]

    async def _do_set_character(char: str):
        if not assistant_tag_fields:
            try:
                build_assistant_tab()
            except Exception:
                pass
        if _combo_char_tf_ref:
            _combo_char_tf_ref[0].value = char
            _combo_char_tf_ref[0].update()

    def _set_character(char: str, platform: str | None):
        """API：写入角色名到 combo 输入框（调度到主线程）"""
        if _page_ref:
            _page_ref[0].run_task(_do_set_character, char)

    async def _do_set_theme(theme: str):
        if not assistant_tag_fields:
            try:
                build_assistant_tab()
            except Exception:
                pass
        if _combo_theme_tf_ref:
            _combo_theme_tf_ref[0].value = theme
            _combo_theme_tf_ref[0].update()

    def _set_theme(theme: str, platform: str | None):
        """API：写入主题到 combo 输入框（调度到主线程）"""
        if _page_ref:
            _page_ref[0].run_task(_do_set_theme, theme)

    def _translate(char: str, theme: str, platform: str | None, targets: list[str]):
        """API：组合角色+主题并翻译"""
        composed = f"{char}の{theme}" if char and theme else (char or theme)
        plat_list = [platform] if platform else PLATFORMS
        for p in plat_list:
            do_translate(composed, p)

    # 懒加载模式：API 回调内部按需调用 build_assistant_tab()
    assist_api.register("set_character", _set_character)
    assist_api.register("set_theme", _set_theme)
    assist_api.register("set_activity_tags", _set_activity_tags)
    assist_api.register("auto_tags", lambda platform: _page_ref[0].run_task(_do_auto_tags, platform) if _page_ref else None)
    assist_api.register("translate", _translate)
    assist_api.register("get_presets", lambda: {
        "char_translations": get_char_translations(),
        "combo_presets": presets.get("combo_presets", []),
        "char_history": presets.get("char_history", []),
        "theme_history": presets.get("theme_history", []),
        "activity_history": presets.get("activity_history", []),
    })
    assist_api.register("get_inputs", lambda: {
        "character": _combo_char_tf_ref[0].value if _combo_char_tf_ref else "",
        "theme": _combo_theme_tf_ref[0].value if _combo_theme_tf_ref else "",
    })
    assist_api.register("get_dev_logs", lambda: {
        "open": _dev_console_open[0],
        "lines": _dev_log_lines.copy(),
    })

    # 启动协助 API
    api_cfg = settings.get("assist_api", {})
    if api_cfg.get("enabled", True):
        assist_api.start(
            host=api_cfg.get("host", "0.0.0.0"),
            port=int(api_cfg.get("port", 8765)),
            token=api_cfg.get("token", ""),
        )

    # ──────────────────────────────────────────────────────
    #  构建平台 Tab 页内容（原有Tab）
    # ──────────────────────────────────────────────────────
    def build_platform_tab(platform: str) -> ft.Control:
        """构建平台 Tab"""
        cfg = PLATFORMS[platform]
        max_tags = cfg["max_tags"]
        color = cfg["color"]

        unified_tf = ft.TextField(
            label="📝 内容编辑（第一行 = 标题，其余 #开头 = Tags）",
            hint_text="瑶瑶の依赖摇\n#原神 #瑶瑶 #genshinimpact\n（输入标题后自动翻译）",
            multiline=True,
            min_lines=5,
            max_lines=10,
            expand=True,
            border_color=color,
            focused_border_color=color,
            text_size=13,
        )
        tag_fields[platform] = unified_tf

        tag_chip_ref = ft.Ref[ft.Container]()
        cnt_lbl = ft.Text("0/" + str(max_tags), size=12, color=ft.Colors.GREEN_400)
        tag_count_labels[platform] = cnt_lbl
        tag_chip_containers[platform] = tag_chip_ref

        def _replace_title(text: str, new_title: str) -> str:
            lines = text.splitlines()
            for i, line in enumerate(lines):
                if line.strip() and not line.strip().startswith("#"):
                    lines[i] = new_title
                    return "\n".join(lines)
            return new_title + ("\n" + "\n".join(lines) if lines else "")

        def _on_text_change(_):
            _refresh_tag_chips(platform)

        unified_tf.on_change = _on_text_change

        # ── 角色输入（带历史下拉） ──
        char_tf = ft.TextField(
            label="🎭 角色名",
            hint_text="输入或选择历史...",
            width=180,
            dense=True,
        )
        char_suggestions = ft.Dropdown(
            label="",
            hint_text="选择历史记录",
            visible=False,
            width=180,
            on_select=lambda e, ctf=char_tf: (
                setattr(ctf, 'value', e.control.value),
                setattr(e.control, 'visible', False),
                e.control.update(), ctf.update()
            ) if e.control.value else None,
        )

        def update_char_suggestions():
            history = get_char_history()
            if history:
                char_suggestions.options = [ft.dropdown.Option(h) for h in history]
                char_suggestions.visible = True
            else:
                char_suggestions.visible = False
            char_suggestions.update()

        char_tf.on_focus = lambda _: update_char_suggestions()

        # ── 主题输入（带历史下拉） ──
        theme_tf = ft.TextField(
            label="🎨 主题",
            hint_text="输入或选择历史...",
            width=180,
            dense=True,
        )
        theme_suggestions = ft.Dropdown(
            label="",
            hint_text="选择历史记录",
            visible=False,
            width=180,
            on_select=lambda e, ttf=theme_tf: (
                setattr(ttf, 'value', e.control.value),
                setattr(e.control, 'visible', False),
                e.control.update(), ttf.update()
            ) if e.control.value else None,
        )

        def update_theme_suggestions():
            history = get_theme_history()
            if history:
                theme_suggestions.options = [ft.dropdown.Option(h) for h in history]
                theme_suggestions.visible = True
            else:
                theme_suggestions.visible = False
            theme_suggestions.update()

        theme_tf.on_focus = lambda _: update_theme_suggestions()

        def _on_compose_title(_):
            char = char_tf.value or ""
            theme = theme_tf.value or ""
            if not char and not theme:
                _show_status("⚠️ 请输入角色或主题", ft.Colors.AMBER_400)
                page.update()
                return
            # 记录历史
            if char:
                add_char_history(char)
            if theme:
                add_theme_history(theme)
            composed = f"{char}の{theme}" if char and theme else (char or theme)
            cur = unified_tf.value or ""
            unified_tf.value = _replace_title(cur, composed)
            unified_tf.update()
            if settings.get("auto_translate", True):
                do_translate(composed, platform)
            # 刷新下拉
            update_char_suggestions()
            update_theme_suggestions()

        compose_btn = ft.Button("✨ 组合标题", on_click=_on_compose_title,
                                         color=ft.Colors.WHITE, bgcolor=color)

        # 翻译回调
        def _on_title_input(_):
            title = _extract_title(unified_tf.value or "")
            if title and settings.get("auto_translate", True) and len(title) >= 2:
                do_translate(title, platform)

        # ── 快捷 Tag 按钮 ──
        def _make_cat_row(cat: str):
            cat_tags = presets.get("tags", {}).get(cat, [])
            chips = []
            for t in cat_tags[:12]:
                def _make_add(tag):
                    def _add(_):
                        cur = unified_tf.value or "\n"
                        existing = parse_tags(cur)
                        if tag.lower() in [x.lower() for x in existing]:
                            return
                        max_t = PLATFORMS[platform]["max_tags"]
                        if len(existing) >= max_t:
                            return
                        unified_tf.value = (cur.rstrip() + f"\n#{tag}").lstrip("\n")
                        _refresh_tag_chips(platform)
                        unified_tf.update()
                    return _add
                chips.append(ft.Chip(
                    label=ft.Text(f"#{t}", size=11),
                    on_click=_make_add(t),
                    bgcolor=ft.Colors.with_opacity(0.12, color),
                ))
            return ft.Column([
                ft.Text(f"📌 {cat}", size=12, weight=ft.FontWeight.BOLD),
                ft.Row(chips, wrap=True, spacing=3, run_spacing=3),
            ], spacing=3)

        def _on_auto_tag(_):
            do_auto_tags(platform)

        auto_tag_btn = ft.OutlinedButton("🏷️ 自动补全", on_click=_on_auto_tag)
        clear_btn = ft.OutlinedButton("🗑️ 清空", on_click=lambda _: (
            setattr(unified_tf, "value", ""), _refresh_tag_chips(platform), unified_tf.update()))
        translate_btn = ft.OutlinedButton("🌐 翻译标题", on_click=_on_title_input)

        cat_rows = [_make_cat_row(cat) for cat in TAG_CATEGORIES]

        _refresh_tag_chips(platform)

        return ft.Column([
            ft.Container(
                content=ft.Column([
                    ft.Text("🎯 快速组合标题", size=15, weight=ft.FontWeight.BOLD),
                    ft.Row([
                        ft.Column([char_tf, char_suggestions]),
                        ft.Column([theme_tf, theme_suggestions]),
                        compose_btn,
                        translate_btn,
                    ], spacing=4, wrap=True),
                ], spacing=8),
                padding=ft.Padding.symmetric(horizontal=12, vertical=10),
                bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.WHITE),
                border_radius=8,
            ),
            ft.Divider(height=6),
            ft.Container(
                content=ft.Column([
                    ft.Text("📋 统一内容编辑区", size=15, weight=ft.FontWeight.BOLD),
                    unified_tf,
                    ft.Divider(height=4),
                    ft.Row([
                        ft.Text("🏷️ 已识别标签", size=13, weight=ft.FontWeight.BOLD),
                        cnt_lbl,
                        ft.Container(expand=True),
                        auto_tag_btn,
                        clear_btn,
                    ], alignment=ft.MainAxisAlignment.START),
                    ft.Container(ref=tag_chip_ref, content=ft.Column([], spacing=4)),
                ], spacing=8),
                padding=ft.Padding.symmetric(horizontal=12, vertical=10),
                bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.WHITE),
                border_radius=8,
            ),
            ft.Divider(height=6),
            ft.Container(
                content=ft.Column([
                    ft.Text("⚡ 快捷添加标签", size=15, weight=ft.FontWeight.BOLD),
                    *cat_rows,
                ], spacing=8),
                padding=ft.Padding.symmetric(horizontal=12, vertical=10),
                bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.WHITE),
                border_radius=8,
            ),
        ], spacing=8, scroll=ft.ScrollMode.AUTO, expand=True)

    # ──────────────────────────────────────────────────────
    #  快速组合 TextField（提升到 Tab 构建之外，只创建一次）
    # ──────────────────────────────────────────────────────
    combo_char_tf = ft.TextField(
        label="🎭 角色",
        hint_text="输入或选择历史...",
        width=200,
        dense=True,
        value=_last.get("last_char", ""),
        on_change=lambda e: _save_last_char(e.control.value or ""),
        on_focus=lambda _: update_combo_char_suggestions(),
        on_submit=lambda _: _on_combo_apply(None),
    )
    _combo_char_tf_ref.append(combo_char_tf)
    combo_theme_tf = ft.TextField(
        label="🎨 主题",
        hint_text="输入主题...",
        width=200,
        dense=True,
        value=_last.get("last_theme", ""),
        on_change=lambda e: _save_last_theme(e.control.value or ""),
        on_focus=lambda _: update_combo_theme_suggestions(),
        on_submit=lambda _: _on_combo_apply(None),
    )
    _combo_theme_tf_ref.append(combo_theme_tf)

    def build_assistant_tab() -> ft.Control:
        """构建助手 Tab：同时展示4个平台编辑区"""
        platform_cols = []
        
        for platform in PLATFORMS:
            cfg = PLATFORMS[platform]
            max_tags = cfg["max_tags"]
            color = cfg["color"]

            unified_tf = ft.TextField(
                label="内容编辑（第一行=标题，其余 #开头=Tags）",
                hint_text=f"输入标题，如：瑶瑶の冒险\n#原神 #二次元 #游戏",
                multiline=True,
                min_lines=4,
                max_lines=8,
                expand=True,
                border_color=color,
                focused_border_color=color,
                text_size=12,
            )
            assistant_tag_fields[platform] = unified_tf
            tag_fields[platform] = unified_tf  # 初始时助手Tab是默认tab

            tag_chip_ref = ft.Ref[ft.Container]()
            cnt_lbl = ft.Text("0/" + str(max_tags), size=11, color=ft.Colors.GREEN_400)
            tag_count_labels[platform] = cnt_lbl
            tag_chip_containers[platform] = tag_chip_ref

            def _replace_title(text: str, new_title: str) -> str:
                lines = text.splitlines()
                for i, line in enumerate(lines):
                    if line.strip() and not line.strip().startswith("#"):
                        lines[i] = new_title
                        return "\n".join(lines)
                return new_title + ("\n" + "\n".join(lines) if lines else "")

            unified_tf.on_change = lambda _, p=platform: _refresh_tag_chips(p)

            # 活动Tag — 多输入框模式
            # 收集本平台所有活动Tag TextField（动态增删）
            activity_tf_list: list[ft.TextField] = []
            activity_inputs_col = ft.Column([], spacing=4)

            def _make_activity_row(p, col, tf_list, default_val=""):
                """创建一行活动Tag输入框（含删除按钮）"""
                tf = ft.TextField(
                    label="🎪 活动Tag",
                    hint_text="填入活动Tag",
                    dense=True,
                    width=130,
                    value=default_val,
                    on_change=lambda e, _p=p: _save_last_activity(_p, e.control.value or ""),
                )
                # 用 id(tf) 定位，确保删除正确的行
                def _del_row(_):
                    for i, _tf in enumerate(tf_list):
                        if _tf is tf:
                            del tf_list[i]
                            break
                    col.controls = [r for r in col.controls if r is not row]
                    col.update()
                    if page and hasattr(page, 'update'):
                        try:
                            page.update()
                        except Exception:
                            pass
                row = ft.Row([
                    tf,
                    ft.IconButton(ft.icons.Icons.REMOVE, icon_color=ft.Colors.RED_300,
                                   on_click=_del_row, tooltip="删除此输入框"),
                ], spacing=4, alignment=ft.MainAxisAlignment.START)
                tf_list.append(tf)
                col.controls.append(row)
                return tf, row

            # 初始一行
            _last_at = _last.get("activity", {}).get(platform, "")
            _make_activity_row(platform, activity_inputs_col, activity_tf_list, _last_at)

            # 预设下拉（附加到第一行）
            _atf_list_ref = activity_tf_list  # 立即捕获当前平台的列表引用
            activity_preset_dd = ft.Dropdown(
                hint_text="预设",
                visible=False,
                width=100,
                on_select=lambda e, p=platform, tfl=_atf_list_ref: (
                    [tf.update() for tf in tfl],
                    setattr(e.control, 'visible', False),
                    e.control.update(),
                ) if e.control.value else None,
            )

            def _show_activity_presets(p, tf_list, col, dd):
                def _show(_):
                    acts = presets.get("activity_tag_presets", {}).get(p, [])
                    if not acts:
                        return
                    dd.options = [
                        ft.dropdown.Option(f"{a.get('name','')}：{' '.join(a.get('tags',[]))}")
                        for a in acts
                    ]
                    # 预设选中后自动填入最后一个空输入框
                    def _on_preset(e):
                        if not e.control.value:
                            return
                        val = e.control.value.split("：")[1] if "：" in (e.control.value or "") else (e.control.value or "")
                        # 找空输入框或新增一行填入
                        filled = False
                        for tf in tf_list:
                            if not (tf.value or "").strip():
                                tf.value = val
                                filled = True
                                break
                        if not filled:
                            _make_activity_row(p, col, tf_list, val)
                        e.control.value = ""
                        e.control.visible = False
                        e.control.update()
                        col.update()
                        [tf.update() for tf in tf_list]
                    dd.on_select = _on_preset
                    dd.visible = True
                    dd.update()
                return _show

            if activity_tf_list:
                activity_tf_list[0].on_focus = _show_activity_presets(platform, activity_tf_list, activity_inputs_col, activity_preset_dd)

            def _add_activity(p, tf_list, col):
                def _do(_):
                    all_tags = []
                    for tf in tf_list:
                        raw = (tf.value or "").strip()
                        if not raw:
                            continue
                        tags = parse_tags(raw)
                        if not tags and raw:
                            tags = [raw]
                        all_tags.extend(tags)
                    _dev_log(f"[DEBUG] _add_activity: p={p}, all_tags={all_tags}, tf_count={len(tf_list)}")
                    if all_tags:
                        add_activity_tags(p, all_tags)
                        _add_activity_history(", ".join(tf.value or "" for tf in tf_list if (tf.value or "").strip()))
                return _do

            activity_add_btn = ft.IconButton(
                ft.icons.Icons.ADD,
                icon_color=ft.Colors.GREEN_400,
                on_click=_add_activity(platform, activity_tf_list, activity_inputs_col),
                tooltip="填入活动Tag",
            )

            def _new_activity_input(p, col, tf_list):
                """新增一行活动Tag输入框"""
                _make_activity_row(p, col, tf_list)
                col.update()
                if page and hasattr(page, 'update'):
                    try:
                        page.update()
                    except Exception:
                        pass

            add_activity_input_btn = ft.TextButton(
                "＋ 增加活动Tag输入框",
                on_click=lambda _, p=platform, col=activity_inputs_col, tf_list=activity_tf_list: _new_activity_input(p, col, tf_list),
                style=ft.ButtonStyle(color=ft.Colors.BLUE_300),
            )

            # 保存活动Tag预设
            def _save_activity_preset(p, tf_list):
                def _do(_):
                    # 从所有输入框收集标签
                    all_vals = []
                    for tf in tf_list:
                        all_vals.append(tf.value or "")
                    combined = " ".join(v for v in all_vals if v.strip())
                    tags = parse_tags(combined)
                    if not tags:
                        tags = combined.split()
                    if not tags:
                        _show_status("⚠️ 请先输入活动Tag", ft.Colors.AMBER_400)
                        return
                    # 弹出保存对话框
                    name_tf = ft.TextField(label="预设名称", hint_text="如：周年庆", expand=True)
                    dlg = ft.AlertDialog(
                        title=ft.Text("💾 保存活动Tag预设"),
                        content=ft.Column([
                            ft.Text(f"当前Tags: {' '.join(f'#{t}' for t in tags)}", size=12, color=ft.Colors.GREY_400),
                            name_tf,
                        ], spacing=10),
                        actions=[
                            ft.TextButton("取消", on_click=lambda _: (setattr(dlg, 'open', False), page.update())),
                            ft.Button("保存", on_click=lambda _, ntf=name_tf, ts=tags, pf=p: (
                                (lambda: (
                                    save_activity_tag_preset(pf, ntf.value.strip(), ts),
                                    setattr(dlg, 'open', False),
                # SnackBar removed (unparseable)
                                    page.update()
                                ))()
                            )),
                        ],
                    )
                    page.dialog = dlg
                    dlg.open = True
                    page.update()
                return _do

            activity_save_btn = ft.IconButton(
                ft.icons.Icons.SAVE,
                icon_color=ft.Colors.BLUE_400,
                on_click=_save_activity_preset(platform, activity_tf_list),
                tooltip="保存为预设",
            )

            def _on_auto_tag(p, tf_list):
                def _do(_):
                    all_vals = []
                    for tf in tf_list:
                        all_vals.append(tf.value or "")
                    combined = " ".join(v for v in all_vals if v.strip())
                    tags = parse_tags(combined)
                    if tags:
                        add_activity_tags(p, tags)
                        for tf in tf_list:
                            tf.value = ""
                            tf.update()
                    do_auto_tags(p)
                return _do

            def _on_clear(p):
                def _do(_):
                    tf = tag_fields.get(p)
                    if tf:
                        tf.value = ""
                        _refresh_tag_chips(p)
                        tf.update()
                return _do

            def _on_translate(p):
                def _do(_):
                    title = _extract_title(unified_tf.value or "")
                    if title:
                        do_translate(title, p)
                return _do

            _refresh_tag_chips(platform)

            # 平台卡片
            card = ft.Container(
                content=ft.Column([
                    ft.Container(
                        content=ft.Row([
                            ft.Text(cfg["label"], size=14, weight=ft.FontWeight.BOLD, color=color),
                            ft.Container(expand=True),
                            cnt_lbl,
                        ]),
                        padding=ft.Padding.only(bottom=4),
                    ),
                    ft.Container(content=ft.Column([
                        ft.Row([activity_preset_dd, activity_add_btn, activity_save_btn, add_activity_input_btn], spacing=4),
                        activity_inputs_col,
                        unified_tf,
                    ], spacing=4), padding=4, border_radius=6,
                        bgcolor=ft.Colors.with_opacity(0.03, ft.Colors.WHITE)),
                    ft.Container(
                        ref=tag_chip_ref,
                        content=ft.Column([], spacing=2),
                        padding=ft.Padding.only(top=4),
                    ),
                    ft.Row([
                        ft.Button("🏷️ Tag", on_click=_on_auto_tag(platform, activity_tf_list),
                                          bgcolor=ft.Colors.with_opacity(0.15, color)),
                        ft.OutlinedButton("🌐 翻译", on_click=_on_translate(platform)),
                        ft.OutlinedButton("🗑️ 清空", on_click=_on_clear(platform)),
                        ft.Container(expand=True),
                    ], spacing=4),
                ], spacing=6),
                padding=8,
                border=ft.border.all(1, ft.Colors.with_opacity(0.3, color)),
                border_radius=8,
                bgcolor=ft.Colors.with_opacity(0.05, color),
            )
            platform_cols.append(card)

        # 上半部分：4个平台编辑区（小红书+抖音第一行，快手+得物第二行）
        grid_row = ft.Column([
            ft.Row(
                [ft.Container(platform_cols[0], expand=1), ft.Container(platform_cols[1], expand=1)],
                spacing=8,
            ),
            ft.Row(
                [ft.Container(platform_cols[2], expand=1), ft.Container(platform_cols[3], expand=1)],
                spacing=8,
            ),
        ], spacing=8)

        # ── 快速组合区（单独放在底部） ──
        combo_preset_name_tf = ft.TextField(
            label="📝 预设名称",
            hint_text="保存当前组合为预设...",
            width=200,
            dense=True,
        )

        combo_char_suggestions = ft.Dropdown(
            hint_text="历史角色",
            visible=False,
            width=200,
            on_select=lambda e, tf=combo_char_tf: (
                setattr(tf, 'value', e.control.value),
                setattr(e.control, 'visible', False),
                e.control.update(), tf.update()
            ) if e.control.value else None,
        )
        combo_theme_suggestions = ft.Dropdown(
            hint_text="历史主题",
            visible=False,
            width=200,
            on_select=lambda e, tf=combo_theme_tf: (
                setattr(tf, 'value', e.control.value),
                setattr(e.control, 'visible', False),
                e.control.update(), tf.update()
            ) if e.control.value else None,
        )

        def update_combo_char_suggestions():
            history = get_char_history()
            if history:
                combo_char_suggestions.options = [ft.dropdown.Option(h) for h in history]
                combo_char_suggestions.visible = True
            else:
                combo_char_suggestions.visible = False
            combo_char_suggestions.update()

        def update_combo_theme_suggestions():
            history = get_theme_history()
            if history:
                combo_theme_suggestions.options = [ft.dropdown.Option(h) for h in history]
                combo_theme_suggestions.visible = True
            else:
                combo_theme_suggestions.visible = False
            combo_theme_suggestions.update()

        combo_char_tf.on_focus = lambda _: update_combo_char_suggestions()
        combo_theme_tf.on_focus = lambda _: update_combo_theme_suggestions()

        def apply_to_all_platforms(composed: str):
            """应用到所有平台"""
            for platform in PLATFORMS:
                tf = tag_fields.get(platform)
                if not tf:
                    continue
                # 保留现有Tag，只替换标题
                cur = tf.value or ""
                lines = cur.splitlines()
                title_line_idx = next((i for i, l in enumerate(lines)
                                      if l.strip() and not l.strip().startswith("#")), -1)
                if title_line_idx >= 0:
                    # 替换标题，保留Tags
                    tag_lines = [l for l in lines[title_line_idx+1:] if l.strip()]
                    new_lines = [composed] + tag_lines
                    tf.value = "\n".join(new_lines)
                else:
                    tf.value = composed
                _refresh_tag_chips(platform)
                tf.update()

        def _on_combo_apply(_):
            char = combo_char_tf.value or ""
            theme = combo_theme_tf.value or ""
            if not char and not theme:
                _show_status("⚠️ 请输入角色或主题", ft.Colors.AMBER_400)
                page.update()
                return
            if char:
                add_char_history(char)
                _save_last_char(char)
            if theme:
                add_theme_history(theme)
                _save_last_theme(theme)
            composed = f"{char}の{theme}" if char and theme else (char or theme)
            apply_to_all_platforms(composed)
            if settings.get("auto_translate", True):
                for plat in PLATFORMS:
                    do_translate(composed, plat)
            update_combo_char_suggestions()
            update_combo_theme_suggestions()
                # SnackBar removed (unparseable)
            page.update()

        def _on_combo_save_preset(_):
            char = combo_char_tf.value or ""
            theme = combo_theme_tf.value or ""
            name = combo_preset_name_tf.value.strip()
            if not name:
                _show_status("⚠️ 请输入预设名称", ft.Colors.AMBER_400)
                page.update()
                return
            composed = f"{char}の{theme}" if char and theme else (char or theme)
            # 获取第一个有内容的编辑器作为结果
            result = ""
            for plat in PLATFORMS:
                tf = tag_fields.get(plat)
                if tf and tf.value:
                    result = tf.value
                    break
            save_combo_preset(name, char, theme, result)
                # SnackBar removed (unparseable)
            page.update()

        def _on_load_presets(_):
            # 弹出预设加载对话框
            combos = get_combo_presets()
            if not combos:
                _show_status("暂无保存的预设", ft.Colors.CYAN_200)
                page.update()
                return
            
            def on_select_preset(e, dlg):
                selected = dlg.content.controls[0]
                if hasattr(selected, 'value') and selected.value:
                    for c in combos:
                        if c.get("name") == selected.value:
                            combo_char_tf.value = c.get("char", "")
                            combo_theme_tf.value = c.get("theme", "")
                            # 应用到所有平台
                            if c.get("result"):
                                for plat in PLATFORMS:
                                    tf = tag_fields.get(plat)
                                    if tf:
                                        tf.value = c.get("result", "")
                                        _refresh_tag_chips(plat)
                                        tf.update()
                            else:
                                composed = f"{c.get('char', '')}の{c.get('theme', '')}"
                                apply_to_all_platforms(composed)
                            update_combo_char_suggestions()
                            update_combo_theme_suggestions()
                # SnackBar removed (unparseable)
                            page.update()
                            break
                dlg.open = False
                page.update()

            preset_options = [ft.dropdown.Option(c.get("name", "")) for c in combos]
            preset_dd = ft.Dropdown(label="选择预设", options=preset_options, expand=True)
            
            dlg = ft.AlertDialog(
                title=ft.Text("📂 加载预设"),
                content=ft.Column([preset_dd], spacing=10),
                actions=[
                    ft.TextButton("取消", on_click=lambda _: (setattr(dlg, 'open', False), page.update())),
                    ft.Button("加载", on_click=lambda e: on_select_preset(e, dlg)),
                ],
            )
            page.dialog = dlg
            dlg.open = True
            page.update()

        combo_section = ft.Container(
            content=ft.Column([
                ft.Text("🎯 快速组合标题（应用到全部平台）", size=14, weight=ft.FontWeight.BOLD),
                ft.Row([
                    ft.Column([combo_char_tf, combo_char_suggestions]),
                    ft.Column([combo_theme_tf, combo_theme_suggestions]),
                    ft.Column([combo_preset_name_tf]),
                ], spacing=8),
                ft.Row([
                    ft.Button("✨ 组合并应用", on_click=_on_combo_apply, 
                                      bgcolor=ft.Colors.PURPLE_700),
                    ft.Button("💾 保存预设", on_click=_on_combo_save_preset,
                                      bgcolor=ft.Colors.BLUE_700),
                    ft.OutlinedButton("📂 加载预设", on_click=_on_load_presets,
                                      icon=ft.icons.Icons.FOLDER_OPEN),
                    ft.Container(expand=True),
                    ft.OutlinedButton("🌐 全部翻译", on_click=lambda _: translate_all(None),
                                      icon=ft.icons.Icons.TRANSLATE),
                ], spacing=8),
            ], spacing=8),
            padding=ft.Padding.symmetric(horizontal=12, vertical=10),
            bgcolor=ft.Colors.with_opacity(0.08, ft.Colors.PURPLE_200),
            border_radius=8,
        )

        return ft.Column([
            ft.Container(
                content=ft.Text("🚀 助手模式 — 多平台同步编辑", size=16, weight=ft.FontWeight.BOLD,
                               color=ft.Colors.PURPLE_200),
                padding=8,
            ),
            combo_section,
            ft.Divider(height=6),
            grid_row,
        ], spacing=8, scroll=ft.ScrollMode.AUTO, expand=True)

    # ──────────────────────────────────────────────────────
    #  设置页
    # ──────────────────────────────────────────────────────
    def build_settings_tab() -> ft.Control:
        api_host_tf = ft.TextField(
            label="协助 API 监听地址",
            value=settings.get("assist_api", {}).get("host", "0.0.0.0"),
            width=200,
        )
        api_port_tf = ft.TextField(
            label="端口",
            value=str(settings.get("assist_api", {}).get("port", 8765)),
            width=120,
            input_filter=ft.NumbersOnlyInputFilter(),
        )
        api_token_tf = ft.TextField(
            label="Token（空=不鉴权）",
            value=settings.get("assist_api", {}).get("token", ""),
            width=250,
            password=True,
            can_reveal_password=True,
        )
        api_status_lbl = ft.Text(
            "✅ 运行中" if assist_api.is_running() else "⚠️ 未运行",
            color=ft.Colors.GREEN_400 if assist_api.is_running() else ft.Colors.ORANGE_400,
        )

        def restart_api(_):
            settings.setdefault("assist_api", {})
            settings["assist_api"]["host"] = api_host_tf.value
            settings["assist_api"]["port"] = int(api_port_tf.value or "8765")
            settings["assist_api"]["token"] = api_token_tf.value
            save_json(SETTINGS_FILE, settings)
            assist_api.start(
                settings["assist_api"]["host"],
                settings["assist_api"]["port"],
                settings["assist_api"]["token"],
            )
            api_status_lbl.value = "✅ 运行中"
            api_status_lbl.color = ft.Colors.GREEN_400
            page.update()

        key_fields = {}
        key_names = {
            "deepl": "DeepL API Key",
            "baidu_appid": "百度 AppID",
            "baidu_secret": "百度 Secret",
            "youdao_appkey": "有道 AppKey",
            "youdao_secret": "有道 Secret",
            "microsoft_key": "Microsoft Key",
            "microsoft_region": "Microsoft Region",
        }
        key_rows = []
        for k, label in key_names.items():
            tf = ft.TextField(
                label=label,
                value=settings.get("api_keys", {}).get(k, ""),
                width=350,
                password=k not in ("microsoft_region",),
                can_reveal_password=k not in ("microsoft_region",),
            )
            key_fields[k] = tf
            key_rows.append(tf)

        # ── 代理设置 ──
        proxy_cfg = settings.get("api_keys", {}).get("proxy", {})
        proxy_enabled_sw = ft.Switch(
            label="启用代理",
            value=proxy_cfg.get("enabled", False),
        )
        proxy_type_dd = ft.Dropdown(
            label="代理类型",
            value=proxy_cfg.get("type", "http"),
            options=[
                ft.dropdown.Option("http", "HTTP 代理"),
                ft.dropdown.Option("socks5", "SOCKS5 代理"),
            ],
            width=150,
        )
        proxy_host_tf = ft.TextField(
            label="代理地址",
            value=proxy_cfg.get("host", ""),
            hint_text="如：127.0.0.1",
            width=200,
        )
        proxy_port_tf = ft.TextField(
            label="端口",
            value=str(proxy_cfg.get("port", "")),
            hint_text="如：7890",
            width=100,
            input_filter=ft.NumbersOnlyInputFilter(),
        )
        proxy_user_tf = ft.TextField(
            label="用户名（可选）",
            value=proxy_cfg.get("user", ""),
            width=150,
        )
        proxy_pass_tf = ft.TextField(
            label="密码（可选）",
            value=proxy_cfg.get("password", ""),
            width=150,
            password=True,
            can_reveal_password=True,
        )

        def save_keys(_):
            settings.setdefault("api_keys", {})
            for k, tf in key_fields.items():
                settings["api_keys"][k] = tf.value
            # 保存代理配置
            settings["api_keys"]["proxy"] = {
                "enabled": proxy_enabled_sw.value,
                "type": proxy_type_dd.value,
                "host": proxy_host_tf.value,
                "port": int(proxy_port_tf.value) if proxy_port_tf.value.isdigit() else 0,
                "user": proxy_user_tf.value,
                "password": proxy_pass_tf.value,
            }
            save_json(SETTINGS_FILE, settings)
            _show_status("✅ API Key 已保存", ft.Colors.GREEN_400)
            page.update()

        auto_translate_sw = ft.Switch(
            label="中文标题自动翻译",
            value=settings.get("auto_translate", True),
        )
        auto_tag_sw = ft.Switch(
            label="自动补全 Tag",
            value=settings.get("auto_tag", True),
        )

        def save_switches(_):
            settings["auto_translate"] = auto_translate_sw.value
            settings["auto_tag"] = auto_tag_sw.value
            save_json(SETTINGS_FILE, settings)

        auto_translate_sw.on_change = save_switches
        auto_tag_sw.on_change = save_switches

        def export_all(_):
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk(); root.withdraw()
            path = filedialog.asksaveasfilename(
                defaultextension=".json",
                filetypes=[("JSON", "*.json")],
                title="导出设置与预设",
            )
            root.destroy()
            if path:
                export_data = {
                    "settings": copy.deepcopy(settings),
                    "presets": copy.deepcopy(presets),
                }
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(export_data, f, ensure_ascii=False, indent=2)
                # SnackBar removed (unparseable)
                page.update()

        def import_all(_):
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk(); root.withdraw()
            path = filedialog.askopenfilename(
                filetypes=[("JSON", "*.json")],
                title="导入设置与预设",
            )
            root.destroy()
            if path:
                try:
                    with open(path, encoding="utf-8") as f:
                        data = json.load(f)
                    if "settings" in data:
                        settings.update(data["settings"])
                        save_json(SETTINGS_FILE, settings)
                    if "presets" in data:
                        presets.update(data["presets"])
                        save_json(PRESETS_FILE, presets)
                    _show_status("✅ 导入成功，请重启应用生效", ft.Colors.GREEN_400)
                except Exception as e:
                    _show_status(f"❌ 导入失败: {e}", ft.Colors.RED_400)

        return ft.Column([
            ft.Text("⚙️ 设置", size=20, weight=ft.FontWeight.BOLD),
            ft.Divider(),
            ft.Container(
                content=ft.Column([
                    ft.Text("🔌 协助 API 设置", size=15, weight=ft.FontWeight.BOLD),
                    ft.Row([api_host_tf, api_port_tf, api_token_tf]),
                    ft.Row([
                        ft.Button("🔄 重启 API 服务", on_click=restart_api),
                        api_status_lbl,
                    ]),
                    ft.Text("局域网访问地址：http://<本机IP>:端口/api/", size=12,
                            color=ft.Colors.GREY_400),
                ], spacing=8),
                padding=12, border_radius=8,
                bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.WHITE),
            ),
            ft.Divider(),
            ft.Container(
                content=ft.Column([
                    ft.Text("🌐 翻译 API 密钥", size=15, weight=ft.FontWeight.BOLD),
                    ft.Text("（使用 Google/deep-translator 无需填写）", size=12,
                            color=ft.Colors.GREY_400),
                    *key_rows,
                    ft.Divider(height=4),
                    ft.Text("🌍 网络代理设置", size=14, weight=ft.FontWeight.BOLD),
                    ft.Row([proxy_enabled_sw, proxy_type_dd, proxy_host_tf, proxy_port_tf], spacing=8),
                    ft.Row([proxy_user_tf, proxy_pass_tf], spacing=8),
                    ft.Text("提示：启用代理后，翻译请求将通过代理服务器转发", size=11, 
                            color=ft.Colors.GREY_400),
                    ft.Button("💾 保存密钥", on_click=save_keys),
                ], spacing=8),
                padding=12, border_radius=8,
                bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.WHITE),
            ),
            ft.Divider(),
            ft.Container(
                content=ft.Column([
                    ft.Text("🎛️ 功能开关", size=15, weight=ft.FontWeight.BOLD),
                    auto_translate_sw,
                    auto_tag_sw,
                ], spacing=8),
                padding=12, border_radius=8,
                bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.WHITE),
            ),
            ft.Divider(),
            ft.Container(
                content=ft.Column([
                    ft.Text("📦 设置与预设 导出/导入", size=15, weight=ft.FontWeight.BOLD),
                    ft.Row([
                        ft.Button("📤 导出", on_click=export_all,
                                          bgcolor=ft.Colors.BLUE_700),
                        ft.Button("📥 导入", on_click=import_all,
                                          bgcolor=ft.Colors.GREEN_700),
                    ]),
                ], spacing=8),
                padding=12, border_radius=8,
                bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.WHITE),
            ),
        ], spacing=10, scroll=ft.ScrollMode.AUTO, expand=True)

    # ──────────────────────────────────────────────────────
    #  预设管理页
    # ──────────────────────────────────────────────────────
    def build_presets_tab() -> ft.Control:

        def refresh_tag_list(cat: str, lv: ft.ListView):
            lv.controls.clear()
            for tag in presets.get("tags", {}).get(cat, []):
                def make_del(t, category, listview):
                    def _del(_):
                        presets["tags"][category].remove(t)
                        save_json(PRESETS_FILE, presets)
                        refresh_tag_list(category, listview)
                        page.update()
                    return _del
                lv.controls.append(
                    ft.Row([
                        ft.Text(f"#{tag}", expand=True),
                        ft.IconButton(ft.icons.Icons.DELETE_OUTLINE, icon_color=ft.Colors.RED_400,
                                      on_click=make_del(tag, cat, lv), tooltip="删除"),
                    ])
                )
            page.update()

        panels = []
        for cat in TAG_CATEGORIES:
            lv = ft.ListView(spacing=2, height=160, padding=4)
            refresh_tag_list(cat, lv)
            new_tf = ft.TextField(label=f"添加 {cat} Tag", expand=True, dense=True)

            def make_add(category, tf, listview):
                def _add(_):
                    tag = tf.value.strip().lstrip("#")
                    if not tag:
                        return
                    presets.setdefault("tags", {}).setdefault(category, [])
                    if tag not in presets["tags"][category]:
                        presets["tags"][category].append(tag)
                        save_json(PRESETS_FILE, presets)
                        refresh_tag_list(category, listview)
                    tf.value = ""
                    page.update()
                return _add

            panels.append(
                ft.ExpansionPanel(
                    header=ft.ListTile(title=ft.Text(f"📌 {cat} Tag库")),
                    content=ft.Container(
                        content=ft.Column([
                            lv,
                            ft.Row([
                                new_tf,
                                ft.IconButton(ft.icons.Icons.ADD, icon_color=ft.Colors.GREEN_400,
                                              on_click=make_add(cat, new_tf, lv)),
                            ]),
                        ]),
                        padding=8,
                    ),
                    expanded=False,
                )
            )

        expansion_list = ft.ExpansionPanelList(controls=panels, elevation=2)

        # ── 角色历史管理 ──
        char_lv = ft.ListView(spacing=2, height=120, padding=4)
        char_tf = ft.TextField(label="添加角色名", hint_text="输入新角色...", expand=True, dense=True)

        def refresh_char_history():
            char_lv.controls.clear()
            history = get_char_history()
            if not history:
                char_lv.controls.append(ft.Text("暂无历史记录", size=12, color=ft.Colors.GREY_400))
                page.update()
                return
            for idx, char in enumerate(history):
                def make_edit(old_val, lv_ref):
                    def _edit(_):
                        _dlg_ref = [None]
                        edit_tf = ft.TextField(value=old_val, label="角色名")
                        _dlg_ref[0] = ft.AlertDialog(
                            title=ft.Text("✏️ 编辑角色名"),
                            content=edit_tf,
                            actions=[
                                ft.TextButton("取消", on_click=lambda _: (_dlg_ref[0].__setattr__('open', False), page.update())),
                                ft.Button("保存", on_click=lambda _, tf2=edit_tf: (
                                    _do_save_edit(old_val, tf2.value, "char_history", refresh_char_history),
                                    _dlg_ref[0].__setattr__('open', False),
                                    page.update()
                                )),
                            ],
                        )
                        def _do_save_edit(old_val, new_val, key, refresh_fn):
                            if new_val.strip() and new_val != old_val:
                                hist = presets.get(key, [])
                                if old_val in hist:
                                    hist[hist.index(old_val)] = new_val.strip()
                                    presets[key] = hist
                                    save_json(PRESETS_FILE, presets)
                                    refresh_fn()
                        page.dialog = _dlg_ref[0]
                        _dlg_ref[0].open = True
                        page.update()
                    return _edit
                def make_del_char(name):
                    def _d(_):
                        hist = presets.get("char_history", [])
                        if name in hist:
                            hist.remove(name)
                            presets["char_history"] = hist
                            save_json(PRESETS_FILE, presets)
                            refresh_char_history()
                    return _d
                char_lv.controls.append(
                    ft.Row([
                        ft.Text(f"👤 {char}", expand=True, size=13),
                        ft.IconButton(ft.icons.Icons.EDIT, icon_color=ft.Colors.BLUE_400,
                                     on_click=make_edit(char, char_lv), tooltip="编辑"),
                        ft.IconButton(ft.icons.Icons.DELETE_OUTLINE, icon_color=ft.Colors.RED_400,
                                     on_click=make_del_char(char), tooltip="删除"),
                    ], spacing=2)
                )
            page.update()

        refresh_char_history()

        def add_char(_):
            ch = char_tf.value.strip()
            if ch:
                add_char_history(ch)
                refresh_char_history()
            char_tf.value = ""
            page.update()

        # ── 主题历史管理 ──
        theme_lv = ft.ListView(spacing=2, height=120, padding=4)
        theme_tf = ft.TextField(label="添加主题", hint_text="输入新主题...", expand=True, dense=True)

        def refresh_theme_history():
            theme_lv.controls.clear()
            history = get_theme_history()
            if not history:
                theme_lv.controls.append(ft.Text("暂无历史记录", size=12, color=ft.Colors.GREY_400))
                page.update()
                return
            for theme in history:
                def make_edit_theme(old_val, lv_ref):
                    def _edit(_):
                        dlg = ft.AlertDialog(
                            title=ft.Text("✏️ 编辑主题"),
                            content=ft.TextField(value=old_val, label="主题名"),
                            actions=[
                                ft.TextButton("取消", on_click=lambda _: (setattr(dlg, 'open', False), page.update())),
                                ft.Button("保存", on_click=lambda _, tf2=dlg.content: (
                                    _do_save(old_val, tf2.value, "theme_history", refresh_theme_history),
                                    setattr(dlg, 'open', False),
                                    page.update()
                                )),
                            ],
                        )
                        def _do_save(old_val, new_val, key, refresh_fn):
                            if new_val.strip() and new_val != old_val:
                                hist = presets.get(key, [])
                                if old_val in hist:
                                    hist[hist.index(old_val)] = new_val.strip()
                                    presets[key] = hist
                                    save_json(PRESETS_FILE, presets)
                                    refresh_fn()
                        page.dialog = dlg
                        dlg.open = True
                        page.update()
                    return _edit
                def make_del_theme(name):
                    def _d(_):
                        hist = presets.get("theme_history", [])
                        if name in hist:
                            hist.remove(name)
                            presets["theme_history"] = hist
                            save_json(PRESETS_FILE, presets)
                            refresh_theme_history()
                    return _d
                theme_lv.controls.append(
                    ft.Row([
                        ft.Text(f"🎨 {theme}", expand=True, size=13),
                        ft.IconButton(ft.icons.Icons.EDIT, icon_color=ft.Colors.BLUE_400,
                                     on_click=make_edit_theme(theme, theme_lv), tooltip="编辑"),
                        ft.IconButton(ft.icons.Icons.DELETE_OUTLINE, icon_color=ft.Colors.RED_400,
                                     on_click=make_del_theme(theme), tooltip="删除"),
                    ], spacing=2)
                )
            page.update()

        refresh_theme_history()

        def add_theme(_):
            th = theme_tf.value.strip()
            if th:
                add_theme_history(th)
                refresh_theme_history()
            theme_tf.value = ""
            page.update()

        # ── 活动标签历史管理 ──
        activity_hist_lv = ft.ListView(spacing=2, height=120, padding=4)
        activity_hist_tf = ft.TextField(label="添加活动标签", hint_text="输入新活动标签...", expand=True, dense=True)

        def refresh_activity_history():
            activity_hist_lv.controls.clear()
            history = _get_activity_history()
            if not history:
                activity_hist_lv.controls.append(ft.Text("暂无历史记录", size=12, color=ft.Colors.GREY_400))
                page.update()
                return
            for atag in history:
                def make_del_atag(tag, lv_ref):
                    def _d(_):
                        hist = _get_activity_history()
                        if tag in hist:
                            hist.remove(tag)
                            presets["activity_history"] = hist
                            save_json(PRESETS_FILE, presets)
                            refresh_activity_history()
                    return _d
                activity_hist_lv.controls.append(
                    ft.Row([
                        ft.Text(f"🏷️ {atag}", expand=True, size=13),
                        ft.IconButton(ft.icons.Icons.DELETE_OUTLINE, icon_color=ft.Colors.RED_400,
                                     on_click=make_del_atag(atag, activity_hist_lv), tooltip="删除"),
                    ], spacing=2)
                )
            page.update()

        refresh_activity_history()

        def add_activity_hist(_):
            at = activity_hist_tf.value.strip()
            if at:
                _add_activity_history(at)
                refresh_activity_history()
            activity_hist_tf.value = ""
            page.update()

        # ── 角色翻译预设管理 ──
        char_trans_lv = ft.ListView(spacing=4, height=180, padding=4)
        char_trans_tf = ft.TextField(label="中文角色名", hint_text="输入角色名，如：可莉", expand=True, dense=True)
        en_tf = ft.TextField(label="🇺🇸 英文", hint_text="English", expand=True, dense=True)
        ja_tf = ft.TextField(label="🇯🇵 日文", hint_text="日本語", expand=True, dense=True)
        ko_tf = ft.TextField(label="🇰🇷 韩文", hint_text="한국어", expand=True, dense=True)

        def refresh_char_translations():
            char_trans_lv.controls.clear()
            translations = get_char_translations()
            if not translations:
                char_trans_lv.controls.append(ft.Text("暂无翻译预设，点击下方添加", size=12, color=ft.Colors.GREY_400))
                page.update()
                return
            for char_name, trans in translations.items():
                en_val = trans.get("en", "")
                ja_val = trans.get("ja", "")
                ko_val = trans.get("ko", "")

                def make_edit_trans(char, old_trans, lv_ref):
                    def _edit(_):
                        _edit_dlg_ref = [None]
                        en_input = ft.TextField(value=old_trans.get("en", ""), label="🇺🇸 英文")
                        ja_input = ft.TextField(value=old_trans.get("ja", ""), label="🇯🇵 日文")
                        ko_input = ft.TextField(value=old_trans.get("ko", ""), label="🇰🇷 韩文")
                        
                        dlg = ft.AlertDialog(
                            title=ft.Text(f"✏️ 编辑翻译: {char}"),
                            content=ft.Column([
                                ft.TextField(value=char, label="角色名（中文）", disabled=True),
                                en_input,
                                ja_input,
                                ko_input,
                            ], spacing=8),
                            actions=[
                                ft.TextButton("取消", on_click=lambda _: (_edit_dlg_ref[0].open if _edit_dlg_ref[0] else None, page.update())),
                                ft.Button("保存", on_click=lambda _:
                                    (save_char_translation(char, en_input.value, ja_input.value, ko_input.value),
                                     _edit_dlg_ref[0].open if _edit_dlg_ref[0] else None,
                                     page.update(),
                                     refresh_char_translations())),
                            ],
                        )
                        _edit_dlg_ref[0] = dlg
                        page.dialog = dlg
                        dlg.open = True
                        page.update()
                    return _edit

                def make_del_trans(char_name):
                    def _d(_):
                        delete_char_translation(char_name)
                        refresh_char_translations()
                    return _d

                char_trans_lv.controls.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Row([
                                ft.Text(f"👤 {char_name}", size=14, weight=ft.FontWeight.BOLD, expand=True),
                                ft.IconButton(ft.icons.Icons.EDIT, icon_color=ft.Colors.BLUE_400,
                                             on_click=make_edit_trans(char_name, trans, char_trans_lv), tooltip="编辑"),
                                ft.IconButton(ft.icons.Icons.DELETE_OUTLINE, icon_color=ft.Colors.RED_400,
                                             on_click=make_del_trans(char_name), tooltip="删除"),
                            ]),
                            ft.Row([
                                ft.Text(f"EN: {en_val or '—'}", size=11, color=ft.Colors.GREY_400, expand=True),
                                ft.Text(f"JA: {ja_val or '—'}", size=11, color=ft.Colors.GREY_400, expand=True),
                                ft.Text(f"KO: {ko_val or '—'}", size=11, color=ft.Colors.GREY_400, expand=True),
                            ]),
                        ], spacing=2),
                        padding=6,
                        border=ft.border.all(1, ft.Colors.with_opacity(0.2, ft.Colors.GREY_400)),
                        border_radius=6,
                    )
                )
            page.update()

        def save_char_trans(_):
            char = char_trans_tf.value.strip()
            en = en_tf.value.strip()
            ja = ja_tf.value.strip()
            ko = ko_tf.value.strip()
            if char:
                save_char_translation(char, en, ja, ko)
                refresh_char_translations()
                char_trans_tf.value = ""
                en_tf.value = ""
                ja_tf.value = ""
                ko_tf.value = ""
                # SnackBar removed (unparseable)
                page.update()

        refresh_char_translations()

        # ── 活动Tag预设管理 ──
        activity_preset_panels = []

        def _edit_preset_act(plat, old_name, new_name, raw_tags, listview, tag_input):
            """编辑已有活动Tag预设"""
            if not new_name or not raw_tags:
                _show_status("⚠️ 名称和Tags不能为空", ft.Colors.AMBER_400)
                return
            tags = parse_tags(raw_tags)
            if not tags:
                tags = raw_tags.split()
            acts = get_activity_tag_presets(plat)
            # 删除旧的同名
            acts[:] = [x for x in acts if x.get("name") != old_name]
            # 插回原位或开头
            acts.insert(0, {"name": new_name, "tags": tags})
            presets["activity_tag_presets"][plat] = acts[:20]
            save_json(PRESETS_FILE, presets)
            # 刷新所有平台的活动Tag预设列表
            for panel in activity_preset_panels:
                if hasattr(panel, '_plat_key') and panel._plat_key == plat:
                    # 找到对应的panel，刷新其内容
                    pass
            _show_status(f"✅ 已更新: {new_name}", ft.Colors.GREEN_400)

        for platform in PLATFORMS:
            cfg = PLATFORMS[platform]
            lv = ft.ListView(spacing=2, height=120, padding=4)
            new_tf = ft.TextField(label=f"预设名称", hint_text="如：周年庆", width=120, dense=True)
            tags_tf = ft.TextField(label=f"活动Tags", hint_text="多个用空格分隔", expand=True, dense=True)

            def refresh_activity_presets(plat, listview, tag_input, _platform=platform):
                listview.controls.clear()
                for p in get_activity_tag_presets(plat):
                    def mk_load(pre, tf_input):
                        def _load(_):
                            tf_input.value = " ".join(pre.get("tags", []))
                            tf_input.update()
                            page.update()
                        return _load
                    def mk_edit(pre, plat_name, listview_ref, tag_input_ref):
                        def _edit(_):
                            _dlg = [None]
                            name_tf = ft.TextField(value=pre.get("name", ""), label="预设名称")
                            tags_tf_edit = ft.TextField(value=" ".join(pre.get("tags", [])), label="活动Tags（空格分隔）", expand=True)
                            dlg = ft.AlertDialog(
                                title=ft.Text(f"✏️ 编辑活动Tag预设"),
                                content=ft.Column([name_tf, tags_tf_edit], spacing=8),
                                actions=[
                                    ft.TextButton("取消", on_click=lambda _: (_dlg[0].__setattr__('open', False), page.update())),
                                    ft.Button("保存", on_click=lambda _, nt=name_tf, tt=tags_tf_edit, pn=plat_name, lv=listview_ref, ti=tag_input_ref: (
                                        _edit_preset_act(pn, pre.get("name", ""), nt.value.strip(), tt.value.strip(), lv, ti),
                                        _dlg[0].__setattr__('open', False),
                                        page.update()
                                    )),
                                ],
                            )
                            _dlg[0] = dlg
                            page.dialog = dlg
                            dlg.open = True
                            page.update()
                        return _edit
                    def mk_del(pre_name, plat_name, tf_input):
                        def _d(_):
                            acts = get_activity_tag_presets(plat_name)
                            acts[:] = [x for x in acts if x.get("name") != pre_name]
                            presets["activity_tag_presets"][plat_name] = acts
                            save_json(PRESETS_FILE, presets)
                            refresh_activity_presets(plat_name, listview, tf_input)
                        return _d
                    tags_str = " ".join(p.get("tags", []))
                    listview.controls.append(
                        ft.Row([
                            ft.Column([
                                ft.Text(p.get("name", ""), size=12, weight=ft.FontWeight.BOLD),
                                ft.Text(tags_str, size=10, color=ft.Colors.GREY_400),
                            ], expand=True, spacing=0),
                            ft.TextButton("加载", on_click=mk_load(p, tag_input)),
                            ft.IconButton(ft.icons.Icons.EDIT, icon_color=ft.Colors.BLUE_400,
                                          on_click=mk_edit(p, plat, listview, tag_input),
                                          tooltip="编辑"),
                            ft.IconButton(ft.icons.Icons.DELETE_OUTLINE, icon_color=ft.Colors.RED_400,
                                          on_click=mk_del(p.get("name", ""), plat, tag_input),
                                          tooltip="删除"),
                        ], spacing=2)
                    )
                page.update()

            def make_save_activity(plat_name, name_tf, tags_tf_input, listview):
                def _save(_):
                    name = name_tf.value.strip()
                    raw_tags = tags_tf_input.value.strip()
                    if not name or not raw_tags:
                        _show_status("⚠️ 请输入名称和活动Tags", ft.Colors.AMBER_400)
                        return
                    tags = parse_tags(raw_tags)
                    if not tags:
                        tags = raw_tags.split()
                    save_activity_tag_preset(plat_name, name, tags)
                    name_tf.value = ""
                    tags_tf_input.value = ""
                    refresh_activity_presets(plat_name, listview, tags_tf_input)
                    _show_status(f"✅ 已保存: {name}", ft.Colors.GREEN_400)
                return _save

            def make_refresh(plat_name, listview, tags_tf_input):
                def _ref(_):
                    refresh_activity_presets(plat_name, listview, tags_tf_input)
                return _ref

            panel = ft.ExpansionPanel(
                header=ft.ListTile(title=ft.Text(f"🎪 {cfg['label']} 活动Tag预设")),
                content=ft.Container(
                    content=ft.Column([
                        ft.Row([new_tf, tags_tf,
                               ft.IconButton(ft.icons.Icons.ADD, icon_color=ft.Colors.GREEN_400,
                                            on_click=make_save_activity(platform, new_tf, tags_tf, lv)),
                               ft.IconButton(ft.icons.Icons.REFRESH, icon_color=ft.Colors.BLUE_400,
                                            on_click=make_refresh(platform, lv, tags_tf),
                                            tooltip="刷新")],
                              spacing=4),
                        lv,
                    ], spacing=6),
                    padding=8,
                ),
                expanded=False,
            )
            panel._plat_key = platform  # 存储平台key用于后续刷新
            activity_preset_panels.append(panel)
            # 初始刷新
            refresh_activity_presets(platform, lv, tags_tf)

        activity_expansion_list = ft.ExpansionPanelList(controls=activity_preset_panels, elevation=2)

        # ── 填充Tag预设管理（普通标签预设）──
        fill_tag_preset_panels = []

        def _edit_fill_tag_preset(plat, old_name, new_name, raw_tags, listview, tag_input):
            """编辑已有填充Tag预设"""
            if not new_name or not raw_tags:
                _show_status("⚠️ 名称和Tags不能为空", ft.Colors.AMBER_400)
                return
            tags = parse_tags(raw_tags)
            if not tags:
                tags = raw_tags.split()
            fill_presets = get_fill_tag_presets(plat)
            fill_presets[:] = [x for x in fill_presets if x.get("name") != old_name]
            fill_presets.insert(0, {"name": new_name, "tags": tags})
            presets["fill_tag_presets"][plat] = fill_presets[:20]
            save_json(PRESETS_FILE, presets)
            refresh_fill_tag_presets(plat, listview, tag_input)
            _show_status(f"✅ 已更新: {new_name}", ft.Colors.GREEN_400)

        for platform in PLATFORMS:
            cfg = PLATFORMS[platform]
            fill_lv = ft.ListView(spacing=2, height=120, padding=4)
            fill_new_tf = ft.TextField(label="预设名称", hint_text="如：穿搭合集", width=120, dense=True)
            fill_tags_tf = ft.TextField(label="Tags", hint_text="多个用空格分隔", expand=True, dense=True)

            def refresh_fill_tag_presets(plat, listview, tag_input, _platform=platform):
                listview.controls.clear()
                for p in get_fill_tag_presets(plat):
                    def mk_fill_load(pre, plat_key, tf_input):
                        def _load(_):
                            # 填充到平台实际的标签输入框
                            tag_tf = tag_fields.get(plat_key)
                            if tag_tf:
                                tag_tf.value = " ".join(pre.get("tags", []))
                                _refresh_tag_chips(plat_key)
                                tag_tf.update()
                            else:
                                tf_input.value = " ".join(pre.get("tags", []))
                                tf_input.update()
                            page.update()
                        return _load
                    def mk_fill_edit(pre, plat_name, listview_ref, tag_input_ref):
                        def _edit(_):
                            _dlg = [None]
                            name_tf = ft.TextField(value=pre.get("name", ""), label="预设名称")
                            tags_tf_edit = ft.TextField(value=" ".join(pre.get("tags", [])), label="Tags（空格分隔）", expand=True)
                            dlg = ft.AlertDialog(
                                title=ft.Text(f"✏️ 编辑填充Tag预设"),
                                content=ft.Column([name_tf, tags_tf_edit], spacing=8),
                                actions=[
                                    ft.TextButton("取消", on_click=lambda _: (_dlg[0].__setattr__('open', False), page.update())),
                                    ft.Button("保存", on_click=lambda _, nt=name_tf, tt=tags_tf_edit, pn=plat_name, lv=listview_ref, ti=tag_input_ref: (
                                        _edit_fill_tag_preset(pn, pre.get("name", ""), nt.value.strip(), tt.value.strip(), lv, ti),
                                        _dlg[0].__setattr__('open', False),
                                        page.update()
                                    )),
                                ],
                            )
                            _dlg[0] = dlg
                            page.dialog = dlg
                            dlg.open = True
                            page.update()
                        return _edit
                    def mk_fill_del(pre_name, plat_name, tf_input):
                        def _d(_):
                            fill_presets = get_fill_tag_presets(plat_name)
                            fill_presets[:] = [x for x in fill_presets if x.get("name") != pre_name]
                            presets["fill_tag_presets"][plat_name] = fill_presets
                            save_json(PRESETS_FILE, presets)
                            refresh_fill_tag_presets(plat_name, listview, tf_input)
                        return _d
                    tags_str = " ".join(p.get("tags", []))
                    listview.controls.append(
                        ft.Row([
                            ft.Column([
                                ft.Text(p.get("name", ""), size=12, weight=ft.FontWeight.BOLD),
                                ft.Text(tags_str, size=10, color=ft.Colors.GREY_400),
                            ], expand=True, spacing=0),
                            ft.TextButton("填充", on_click=mk_fill_load(p, plat, tag_input)),
                            ft.IconButton(ft.icons.Icons.EDIT, icon_color=ft.Colors.BLUE_400,
                                          on_click=mk_fill_edit(p, plat, listview, tag_input),
                                          tooltip="编辑"),
                            ft.IconButton(ft.icons.Icons.DELETE_OUTLINE, icon_color=ft.Colors.RED_400,
                                          on_click=mk_fill_del(p.get("name", ""), plat, tag_input),
                                          tooltip="删除"),
                        ], spacing=2)
                    )
                page.update()

            def make_save_fill_tag(plat_name, name_tf, tags_tf_input, listview):
                def _save(_):
                    name = name_tf.value.strip()
                    raw_tags = tags_tf_input.value.strip()
                    if not name or not raw_tags:
                        _show_status("⚠️ 请输入名称和Tags", ft.Colors.AMBER_400)
                        return
                    tags = parse_tags(raw_tags)
                    if not tags:
                        tags = raw_tags.split()
                    save_fill_tag_preset(plat_name, name, tags)
                    name_tf.value = ""
                    tags_tf_input.value = ""
                    refresh_fill_tag_presets(plat_name, listview, tags_tf_input)
                    _show_status(f"✅ 已保存: {name}", ft.Colors.GREEN_400)
                return _save

            def make_refresh_fill(plat_name, listview, tags_tf_input):
                def _ref(_):
                    refresh_fill_tag_presets(plat_name, listview, tags_tf_input)
                return _ref

            fill_panel = ft.ExpansionPanel(
                header=ft.ListTile(title=ft.Text(f"🏷️ {cfg['label']} 填充Tag预设")),
                content=ft.Container(
                    content=ft.Column([
                        ft.Row([fill_new_tf, fill_tags_tf,
                               ft.IconButton(ft.icons.Icons.ADD, icon_color=ft.Colors.GREEN_400,
                                            on_click=make_save_fill_tag(platform, fill_new_tf, fill_tags_tf, fill_lv)),
                               ft.IconButton(ft.icons.Icons.REFRESH, icon_color=ft.Colors.BLUE_400,
                                            on_click=make_refresh_fill(platform, fill_lv, fill_tags_tf),
                                            tooltip="刷新")],
                              spacing=4),
                        fill_lv,
                    ], spacing=6),
                    padding=8,
                ),
                expanded=False,
            )
            fill_panel._plat_key = platform
            fill_tag_preset_panels.append(fill_panel)
            refresh_fill_tag_presets(platform, fill_lv, fill_tags_tf)

        fill_tag_expansion_list = ft.ExpansionPanelList(controls=fill_tag_preset_panels, elevation=2)

        # ── 组合预设管理（增强版） ──
        combo_lv = ft.ListView(spacing=2, height=180, padding=4)
        combo_dd = ft.Dropdown(
            label="💾 快速选择组合预设",
            hint_text="选择预设快速应用...",
            expand=True,
            options=[],
            on_select=lambda e: _apply_combo_by_name(e.control.value) if e.control.value else None,
        )

        def _apply_combo_by_name(name):
            """根据名称应用预设"""
            if not name:
                return
            combos = get_combo_presets()
            for pre in combos:
                if pre.get("name") == name:
                    if pre.get("result"):
                        for plat in PLATFORMS:
                            tf = assistant_tag_fields.get(plat) or tag_fields.get(plat)
                            if tf:
                                tf.value = pre.get("result", "")
                                _refresh_tag_chips(plat)
                                tf.update()
                    else:
                        composed = f"{pre.get('char', '')}の{pre.get('theme', '')}"
                        for plat in PLATFORMS:
                            tf = assistant_tag_fields.get(plat) or tag_fields.get(plat)
                            if tf:
                                tf.value = _replace_title(tf.value or "", composed)
                                tf.update()
                # SnackBar removed (unparseable)
                    page.update()
                    break

        def refresh_combos():
            combo_lv.controls.clear()
            combos = get_combo_presets()
            # 更新下拉选项
            combo_dd.options = [ft.dropdown.Option(c.get("name", "")) for c in combos] if combos else []
            if not combos:
                combo_lv.controls.append(ft.Text("暂无保存的预设", size=12, color=ft.Colors.GREY_400))
                # 只在控件已添加到页面时才更新
                try:
                    if combo_dd.page:
                        combo_dd.update()
                        page.update()
                except RuntimeError:
                    pass
                return
            
            for c in combos:
                char = c.get("char", "")
                theme = c.get("theme", "")
                name = c.get("name", "")
                result = c.get("result", "")
                tags_count = len(parse_tags(result))
                title_preview = _extract_title(result)[:25] if result else ""

                def mk_apply(pre):
                    def _apply(_):
                        if pre.get("result"):
                            for plat in PLATFORMS:
                                tf = assistant_tag_fields.get(plat) or tag_fields.get(plat)
                                if tf:
                                    tf.value = pre.get("result", "")
                                    _refresh_tag_chips(plat)
                                    tf.update()
                        else:
                            composed = f"{pre.get('char', '')}の{pre.get('theme', '')}"
                            for plat in PLATFORMS:
                                tf = assistant_tag_fields.get(plat) or tag_fields.get(plat)
                                if tf:
                                    tf.value = _replace_title(tf.value or "", composed)
                                    tf.update()
                # SnackBar removed (unparseable)
                        page.update()
                    return _apply

                def mk_del(pre_name):
                    def _del(_):
                        combos_list = presets.get("combo_presets", [])
                        presets["combo_presets"] = [x for x in combos_list if x.get("name") != pre_name]
                        save_json(PRESETS_FILE, presets)
                        refresh_combos()
                    return _del

                def mk_edit(pre):
                    def _edit(_):
                        dlg = ft.AlertDialog(
                            title=ft.Text(f"✏️ 编辑组合预设: {pre.get('name')}"),
                            content=ft.Column([
                                ft.TextField(value=pre.get("name", ""), label="预设名称"),
                                ft.TextField(value=pre.get("char", ""), label="角色"),
                                ft.TextField(value=pre.get("theme", ""), label="主题"),
                                ft.TextField(value=pre.get("result", ""), label="完整内容", multiline=True, min_lines=3),
                            ], spacing=8),
                            actions=[
                                ft.TextButton("取消", on_click=lambda _: (setattr(dlg, 'open', False), page.update())),
                                ft.Button("保存", on_click=lambda _, d=dlg: (
                                    _do_save_combo(pre.get("name"), d.content.controls[0].value, 
                                                  d.content.controls[1].value, d.content.controls[2].value,
                                                  d.content.controls[3].value),
                                    setattr(dlg, 'open', False),
                                    page.update()
                                )),
                            ],
                        )
                        def _do_save_combo(old_name, new_name, new_char, new_theme, new_result):
                            combos_list = presets.get("combo_presets", [])
                            for i, c in enumerate(combos_list):
                                if c.get("name") == old_name:
                                    combos_list[i] = {
                                        "name": new_name.strip() or old_name,
                                        "char": new_char.strip(),
                                        "theme": new_theme.strip(),
                                        "result": new_result,
                                    }
                                    break
                            presets["combo_presets"] = combos_list
                            save_json(PRESETS_FILE, presets)
                            refresh_combos()
                        page.dialog = dlg
                        dlg.open = True
                        page.update()
                    return _edit

                combo_lv.controls.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Row([
                                ft.Column([
                                    ft.Text(name, size=13, weight=ft.FontWeight.BOLD),
                                    ft.Text(f"🎭 {char}  🎨 {theme}", size=11, color=ft.Colors.GREY_400),
                                ], expand=True, spacing=2),
                                ft.Text(f"🏷️ {tags_count}个", size=10, color=ft.Colors.GREY_500),
                            ]),
                            ft.Text(f"📝 {title_preview}..." if title_preview else "（无标题）",
                                   size=10, color=ft.Colors.GREY_500),
                            ft.Row([
                                ft.TextButton("📥 应用", on_click=mk_apply(c),
                                             icon=ft.icons.Icons.DOWNLOAD),
                                ft.TextButton("✏️ 编辑", on_click=mk_edit(c),
                                             icon=ft.icons.Icons.EDIT),
                                ft.IconButton(ft.icons.Icons.DELETE_OUTLINE,
                                             icon_color=ft.Colors.RED_400,
                                             on_click=mk_del(c.get("name", "")),
                                             tooltip="删除"),
                            ], spacing=4),
                        ], spacing=4),
                        padding=8,
                        border=ft.border.all(1, ft.Colors.with_opacity(0.2, ft.Colors.GREY_400)),
                        border_radius=6,
                    )
                )
            # 更新控件
            try:
                if combo_dd.page:
                    combo_dd.update()
                    page.update()
            except RuntimeError:
                pass

        # 批量应用预设
        def _batch_apply_presets(_):
            combos = get_combo_presets()
            if not combos:
                _show_status("⚠️ 暂无预设", ft.Colors.AMBER_400)
                page.update()
                return
            selected_presets = []

            def toggle_preset(name, cb):
                if cb.value:
                    if name not in selected_presets:
                        selected_presets.append(name)
                else:
                    if name in selected_presets:
                        selected_presets.remove(name)

            checkboxes = []
            for c in combos:
                cb = ft.Checkbox(label=c.get("name", ""), value=False,
                                on_change=lambda e, n=c.get("name", ""): toggle_preset(n, e.control))
                checkboxes.append(cb)

            _dlg_ref = [None]  # 使用列表存储对话框引用

            def do_apply():
                if not selected_presets:
                    _show_status("⚠️ 请先选择预设", ft.Colors.AMBER_400)
                    return
                applied_names = []
                for c in combos:
                    if c.get("name", "") in selected_presets:
                        if c.get("result"):
                            for plat in PLATFORMS:
                                tf = assistant_tag_fields.get(plat) or tag_fields.get(plat)
                                if tf:
                                    tf.value = c.get("result", "")
                                    _refresh_tag_chips(plat)
                                    tf.update()
                        applied_names.append(c.get("name", ""))
                if _dlg_ref[0]:
                    _dlg_ref[0].open = False
                page.update()
                # SnackBar removed (unparseable)
                page.update()

            dlg = ft.AlertDialog(
                title=ft.Text("📋 批量应用预设（多选）"),
                content=ft.Column(checkboxes, spacing=4, scroll=ft.ScrollMode.AUTO, height=300),
                actions=[
                    ft.TextButton("取消", on_click=lambda _: (_dlg_ref[0].open if _dlg_ref[0] else None, 
                                                             page.update() if _dlg_ref[0] else None)),
                    ft.Button("✅ 确认应用", on_click=lambda _: do_apply()),
                ],
            )
            _dlg_ref[0] = dlg
            page.dialog = dlg
            dlg.open = True
            page.update()

        return ft.Column([
            ft.Text("🗂️ 预设管理", size=20, weight=ft.FontWeight.BOLD),
            ft.Divider(),
            # 角色历史
            ft.Container(
                content=ft.Column([
                    ft.Text("👤 角色历史", size=15, weight=ft.FontWeight.BOLD),
                    ft.Text("点击编辑按钮可修改历史记录", size=11, color=ft.Colors.GREY_400),
                    char_lv,
                    ft.Row([char_tf,
                            ft.IconButton(ft.icons.Icons.ADD, icon_color=ft.Colors.GREEN_400,
                                          on_click=add_char)]),
                ], spacing=6),
                padding=10, border_radius=8,
                bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.WHITE),
            ),
            # 主题历史
            ft.Container(
                content=ft.Column([
                    ft.Text("🎨 主题历史", size=15, weight=ft.FontWeight.BOLD),
                    ft.Text("点击编辑按钮可修改历史记录", size=11, color=ft.Colors.GREY_400),
                    theme_lv,
                    ft.Row([theme_tf,
                            ft.IconButton(ft.icons.Icons.ADD, icon_color=ft.Colors.GREEN_400,
                                          on_click=add_theme)]),
                ], spacing=6),
                padding=10, border_radius=8,
                bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.WHITE),
            ),
            # 活动标签历史
            ft.Container(
                content=ft.Column([
                    ft.Text("🏷️ 活动标签历史", size=15, weight=ft.FontWeight.BOLD),
                    activity_hist_lv,
                    ft.Row([activity_hist_tf,
                            ft.IconButton(ft.icons.Icons.ADD, icon_color=ft.Colors.GREEN_400,
                                          on_click=add_activity_hist)]),
                ], spacing=6),
                padding=10, border_radius=8,
                bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.WHITE),
            ),
            # 角色翻译预设
            ft.Container(
                content=ft.Column([
                    ft.Text("🌐 角色翻译预设", size=15, weight=ft.FontWeight.BOLD),
                    ft.Text("设置中文角色的英日韩翻译，翻译时优先使用预设", size=11, color=ft.Colors.GREY_400),
                    char_trans_lv,
                    ft.Column([
                        ft.Row([char_trans_tf, ft.IconButton(ft.icons.Icons.ADD, icon_color=ft.Colors.GREEN_400, on_click=save_char_trans)]),
                        ft.Row([en_tf, ja_tf, ko_tf]),
                    ], spacing=4),
                ], spacing=6),
                padding=10, border_radius=8,
                bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.WHITE),
            ),
            # 活动Tag预设
            ft.Container(
                content=ft.Column([
                    ft.Text("🎪 活动Tag预设（点击展开各平台）", size=15, weight=ft.FontWeight.BOLD),
                    ft.Text("保存活动Tag预设，方便快速填入当前活动信息", size=11, color=ft.Colors.GREY_400),
                    activity_expansion_list,
                ], spacing=6),
                padding=10, border_radius=8,
                bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.WHITE),
            ),
            # 填充Tag预设（普通标签预设）
            ft.Container(
                content=ft.Column([
                    ft.Text("🏷️ 填充Tag预设（点击展开各平台）", size=15, weight=ft.FontWeight.BOLD),
                    ft.Text("保存常用标签组合预设，方便一键填入标签输入框", size=11, color=ft.Colors.GREY_400),
                    fill_tag_expansion_list,
                ], spacing=6),
                padding=10, border_radius=8,
                bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.WHITE),
            ),
            # 组合预设管理
            ft.Container(
                content=ft.Column([
                    ft.Text("💾 组合预设管理", size=15, weight=ft.FontWeight.BOLD),
                    ft.Text("在助手页保存组合预设后，可在此管理、编辑、批量应用", size=11, color=ft.Colors.GREY_400),
                    combo_dd,
                    combo_lv,
                    ft.Row([
                        ft.OutlinedButton("🔄 刷新", on_click=lambda _: refresh_combos()),
                        ft.OutlinedButton("📦 批量应用", on_click=_batch_apply_presets,
                                         icon=ft.icons.Icons.PLAYLIST_ADD_CHECK),
                    ], spacing=8),
                ], spacing=6),
                padding=10, border_radius=8,
                bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.WHITE),
            ),
            ft.Divider(),
            ft.Text("🏷️ Tag 库管理（点击展开）", size=15, weight=ft.FontWeight.BOLD),
            expansion_list,
        ], spacing=10, scroll=ft.ScrollMode.AUTO, expand=True)

    # ──────────────────────────────────────────────────────
    #  顶部工具栏
    # ──────────────────────────────────────────────────────
    selected_api_dd = ft.Dropdown(
        label="翻译 API",
        value=settings.get("translation_api", "deep_translator_google"),
        options=[ft.dropdown.Option(a) for a in tr.API_LIST],
        width=240,
    )

    def on_api_change(e):
        settings["translation_api"] = selected_api_dd.value
        save_json(SETTINGS_FILE, settings)

    selected_api_dd.on_change = on_api_change


    def _get_active_tag_fields() -> dict:
        """返回当前活跃 Tab 对应的 tag_fields"""
        if current_tab[0] == "assistant":
            return assistant_tag_fields
        # 平台Tab：只返回当前平台
        if current_tab[0] in PLATFORMS:
            return {current_tab[0]: tag_fields.get(current_tab[0])} if tag_fields.get(current_tab[0]) else {}
        return tag_fields

    def translate_all(_):
        active = _get_active_tag_fields()
        _dev_log(f"[全部翻译] 当前tab={current_tab[0]} 目标平台={list(active.keys())}")
        for plat, unified_tf in active.items():
            if not unified_tf:
                _dev_log(f"[全部翻译] 跳过 {plat}，无控件")
                continue
            try:
                for line in (unified_tf.value or "").splitlines():
                    if line.strip() and not line.strip().startswith("#"):
                        _dev_log(f"[全部翻译] {plat} 标题={line.strip()[:30]}")
                        do_translate(line.strip(), plat)
                        break
            except Exception as ex:
                _dev_log(f"[全部翻译] {plat} 异常: {ex}")

    def autotag_all(_):
        active = _get_active_tag_fields()
        _dev_log(f"[全部Tag] 当前tab={current_tab[0]} 目标平台={list(active.keys())}")
        for plat in active:
            try:
                _dev_log(f"[全部Tag] 执行 do_auto_tags({plat})")
                do_auto_tags(plat)
            except Exception as ex:
                _dev_log(f"[全部Tag] {plat} 异常: {ex}")



    # ── 开发者控制台面板 ──────────────────────────────
    _dev_console_ref: list = [None]          # [ft.Container] 控制台面板引用
    _dev_log_txt = ft.Text("", size=11, font_family="Consolas",
                           color=ft.Colors.CYAN_100, selectable=True)
    _dev_log_ref: list = [_dev_log_txt]

    def _sync_dev_console_ui():
        """[主线程] 同步勾选框的勾选状态"""
        if _dev_console_cb and _dev_console_cb[0]:
            _dev_console_cb[0].value = _dev_console_open[0]
            try:
                _dev_console_cb[0].update()
            except Exception:
                pass

    def _toggle_dev_console(e):
        is_init = getattr(e, "_dev_init", False)
        if is_init:
            _sync_dev_console_ui()
            return
        _dev_console_open[0] = not _dev_console_open[0]
        settings["dev_console_open"] = _dev_console_open[0]
        save_json(SETTINGS_FILE, settings)
        _sync_dev_console_ui()

    # ── 开发者日志面板 ───────────────────────────────────
    # 开发者日志已移除 UI 面板，仅通过 API /api/dev_logs 访问
    # _dev_console_ref 保留但不再引用 UI 控件

    # ── 底部状态栏 ────────────────────────────────────
    _status_lbl = ft.Text("⬢ 就绪", size=12, color=ft.Colors.WHITE38)
    _status_lbl_ref.append(_status_lbl)

    # ── 顶部工具栏 ────────────────────────────────────
    toolbar = ft.Container(
        content=ft.Row([
            ft.Text("🎬 短视频助手", size=18, weight=ft.FontWeight.BOLD,
                    color=ft.Colors.PURPLE_200),
            ft.Container(expand=True),
            selected_api_dd,
            ft.Button("🌐 全部翻译", on_click=translate_all,
                               bgcolor=ft.Colors.BLUE_700),
            ft.Button("🏷️ 全部Tag", on_click=autotag_all,
                               bgcolor=ft.Colors.GREEN_700),
            ft.Checkbox("🛠️ 开发者模式",
                         value=_dev_console_open[0],
                         on_change=_toggle_dev_console,
                         fill_color=ft.Colors.ORANGE_300),
        ], spacing=8),
        padding=ft.Padding.symmetric(horizontal=16, vertical=8),
        bgcolor=ft.Colors.with_opacity(0.1, ft.Colors.PURPLE_200),
    )
    # 保存勾选框引用（必须在 toolbar 创建后）
    _dev_console_cb[0] = toolbar.content.controls[-1]
    # 初始化同步UI（标记 e._dev_init=True，防止 on_change 翻转状态）
    class _InitEvent:
        _dev_init = True
    _toggle_dev_console(_InitEvent())

    # ──────────────────────────────────────────────────────
    #  主 Tab
    # ──────────────────────────────────────────────────────
    tab_keys = ["assistant"] + list(PLATFORMS) + ["presets", "settings"]

    def build_tab_content(key):
        if key == "assistant":
            return ft.Container(build_assistant_tab(),
                               padding=ft.Padding.symmetric(horizontal=16, vertical=12),
                               expand=True)
        elif key in PLATFORMS:
            return ft.Container(build_platform_tab(key),
                               padding=ft.Padding.symmetric(horizontal=16, vertical=12),
                               expand=True)
        elif key == "presets":
            return ft.Container(build_presets_tab(),
                               padding=ft.Padding.symmetric(horizontal=16, vertical=12),
                               expand=True)
        else:
            return ft.Container(build_settings_tab(),
                               padding=ft.Padding.symmetric(horizontal=16, vertical=12),
                               expand=True)

    tab_labels_cfg = (
        [{"value": "assistant", "label": "🚀 助手"}]
        + [{"value": p, "label": PLATFORMS[p]["label"]} for p in PLATFORMS]
        + [{"value": "presets", "label": "🗂️ 预设管理"}]
        + [{"value": "settings", "label": "⚙️ 设置"}]
    )

    current_tab_key = tab_keys[0]

    tab_content_ref = ft.Ref[ft.Container]()
    tab_content_container = ft.Container(ref=tab_content_ref,
                                         content=build_tab_content(current_tab_key),
                                         expand=True)

    # ── Tab值持久化 ──
    # 保存每个平台/助手Tab的内容值，切换时恢复
    _tab_values: dict = {
        "assistant": {},
        **{p: {} for p in PLATFORMS}
    }

    def _save_current_tab():
        """切换前保存当前Tab各平台输入框的值"""
        cur = current_tab[0]
        if cur in ("assistant", "settings", "presets"):
            return
        # 保存助手tab下各平台的值
        for p in PLATFORMS:
            tf = assistant_tag_fields.get(p)
            if tf:
                _tab_values["assistant"][p] = {
                    "unified": tf.value or "",
                }
        # 保存平台tab下自己的值
        tf = tag_fields.get(cur)
        if tf:
            _tab_values[cur] = {"unified": tf.value or ""}

    def _restore_tab(key):
        """切换后恢复Tab值"""
        vals = _tab_values.get(key, {})
        if key == "assistant":
            for p in PLATFORMS:
                tf = assistant_tag_fields.get(p)
                if tf and p in vals:
                    tf.value = vals[p].get("unified", "")
                    tf.update()
        else:
            tf = tag_fields.get(key)
            if tf and key in vals:
                tf.value = vals[key].get("unified", "")
                tf.update()

    def on_tab_change(e):
        sel = e.control.selected
        if not sel:
            return
        key = sel[0]
        _save_current_tab()
        current_tab[0] = key
        # 根据当前tab更新 tag_fields：助手tab用 assistant_tag_fields，平台tab重新注册
        if key == "assistant":
            tag_fields.update(assistant_tag_fields)
        tab_content_ref.current.content = build_tab_content(key)
        tab_content_ref.current.update()
        _restore_tab(key)
        _dev_log(f"[Tab切换] -> {key}  tab_fields包含平台: {list(tag_fields.keys())}")


    segments = [ft.Segment(value=t["value"], label=t["label"]) for t in tab_labels_cfg]
    tab_bar = ft.SegmentedButton(
        segments=segments,
        selected=[current_tab_key],
        allow_empty_selection=False,
        allow_multiple_selection=False,
        on_change=on_tab_change,
        expand=True,
    )

    main_col = ft.Column(
        [toolbar, tab_bar, tab_content_container, _status_lbl],
        spacing=0,
    )

    # 注册 page 引用（供 API 回调调度 UI 更新到主线程）
    _page_ref.append(page)

    page.add(main_col)


if __name__ == "__main__":
    ft.app(target=main)
