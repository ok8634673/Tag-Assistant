# 短视频助手

一款基于 Flet 的多平台短视频标题/Tag 管理工具，支持自动翻译、Tag 补全、局域网协助 API。

## 功能特性

- 📕 **多平台支持**：小红书(50个Tag) / 抖音(5个) / 快手(4个) / 得物(5个)
- 🌐 **三语自动翻译**：中→英/日/韩，支持6种翻译 API 切换
- ✨ **标题自动组合**：角色名の主题 格式，下拉选择快速组合
- 🏷️ **Tag 自动补全**：按分类（游戏/角色/平台活动/通用）点选或自动填充
- 🔌 **局域网协助 API**：AI 助手可通过 HTTP API 远程编辑内容
- 📦 **导出/导入**：所有设置和预设可导出为 JSON，换机迁移方便
- 🗂️ **预设管理**：角色名、主题、Tag库均可增删编辑

## 快速启动

```bash
# 安装依赖
pip install flet deep-translator flask flask-cors httpx

# 运行
python main.py
```

## 依赖

| 包 | 用途 |
|---|---|
| flet | GUI 框架 |
| deep-translator | Google 翻译（免费） |
| flask / flask-cors | 协助 API 服务器 |
| httpx | HTTP 客户端（DeepL/百度/有道/微软翻译） |

## 翻译 API 支持

| API | 是否需要密钥 | 备注 |
|---|---|---|
| deep_translator_google | ❌ 免费 | 默认，推荐 |
| deepl | ✅ | 需要 DeepL Free API Key |
| baidu | ✅ | 百度翻译开放平台 |
| youdao | ✅ | 有道智云 |
| microsoft | ✅ | Azure 认知服务 |

## 协助 API

默认监听 `0.0.0.0:8765`，局域网内其他设备（或 AI 助手）可访问。  
详见 [API文档.md](./API文档.md)

## 文件结构

```
短视频助手/
├── main.py          # 主程序（Flet GUI）
├── translator.py    # 多 API 翻译模块
├── assist_api.py    # 局域网协助 API 服务
├── data/
│   ├── presets.json # 预设（角色/主题/Tag库）
│   └── settings.json # 设置（翻译API/协助API配置）
├── API文档.md
└── README.md
```
