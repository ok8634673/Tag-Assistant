@echo off
chcp 65001 >nul 2>&1
title 短视频助手 - 启动检查
color 0A

echo.
echo  ╔══════════════════════════════════════╗
echo  ║       短视频助手  一键启动           ║
echo  ╚══════════════════════════════════════╝
echo.

:: ── 切换到脚本所在目录 ──────────────────────────
cd /d "%~dp0"

:: ── 检查 Python ─────────────────────────────────
echo [1/3] 检查 Python...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  ❌ 未检测到 Python，请先安装 Python 3.9+
    echo     下载地址：https://www.python.org/downloads/
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('python --version 2^>^&1') do echo  ✅ %%v

:: ── 检查并安装依赖 ───────────────────────────────
echo.
echo [2/3] 检查依赖包...
echo.

set MISSING=0

call :check_pkg flet
call :check_pkg deep-translator

call :check_pkg flask
call :check_pkg flask-cors
call :check_pkg httpx

if %MISSING% equ 1 (
    echo.
    echo  正在安装缺少的依赖，请稍候...
    pip install flet deep-translator flask flask-cors httpx -q
    if %errorlevel% neq 0 (
        echo  ❌ 依赖安装失败，请检查网络或手动运行：
        echo     pip install flet deep-translator flask flask-cors httpx
        pause
        exit /b 1
    )
    echo  ✅ 依赖安装完成
)

:: ── 启动主程序 ───────────────────────────────────
echo.
echo [3/3] 启动短视频助手...
echo.
python main.py

if %errorlevel% neq 0 (
    echo.
    echo  ❌ 程序异常退出，错误码：%errorlevel%
    pause
)
exit /b 0

:: ────────────────────────────────────────────────
:: 子程序：检查单个包
:: ────────────────────────────────────────────────
:check_pkg
python -c "import importlib.util; exit(0 if importlib.util.find_spec('%~1'.replace('-','_')) else 1)" >nul 2>&1
if %errorlevel% neq 0 (
    :: 部分包名含连字符，用 pip show 二次确认
    pip show %~1 >nul 2>&1
    if %errorlevel% neq 0 (
        echo  ⚠️  缺少：%~1
        set MISSING=1
    ) else (
        echo  ✅ %~1
    )
) else (
    echo  ✅ %~1
)
goto :eof
