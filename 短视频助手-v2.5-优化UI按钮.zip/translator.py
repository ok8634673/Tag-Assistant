"""
translator.py — 多 API 冗余翻译模块
支持：deep_translator_google / deepl / baidu / youdao / microsoft
支持 HTTP/SOCKS5 代理
"""
import hashlib, random, time, urllib.parse, json, logging
import httpx

logger = logging.getLogger("translator")

# ──────────────────────────────────────────────────────────
#  代理支持
# ──────────────────────────────────────────────────────────
def _build_proxy_url(proxy_cfg: dict) -> str | None:
    """
    构建代理URL，支持 HTTP 和 SOCKS5
    proxy_cfg: {"type": "http"|"socks5", "host": "...", "port": ..., "user"?, "password"?}
    返回 proxy URL 或 None
    """
    if not proxy_cfg or not proxy_cfg.get("enabled"):
        return None
    
    ptype = proxy_cfg.get("type", "http")
    host = proxy_cfg.get("host", "")
    port = proxy_cfg.get("port", "")
    
    if not host or not port:
        return None
    
    user = proxy_cfg.get("user", "")
    password = proxy_cfg.get("password", "")
    
    if user and password:
        if ptype == "socks5":
            return f"socks5://{user}:{password}@{host}:{port}"
        else:
            return f"http://{user}:{password}@{host}:{port}"
    else:
        if ptype == "socks5":
            return f"socks5://{host}:{port}"
        else:
            return f"http://{host}:{port}"


def _get_httpx_client(proxy_url: str | None = None) -> httpx.Client:
    """获取配置了代理的 httpx.Client"""
    if proxy_url:
        return httpx.Client(proxy=proxy_url, timeout=15)
    return httpx.Client(timeout=15)


# ──────────────────────────────────────────────────────────
#  1. deep-translator (Google, 免费无需 key) ← 主推
# ──────────────────────────────────────────────────────────
def _deep_translator_google(text: str, target: str, proxy_cfg: dict = None) -> str:
    """
    deep_translator 支持代理，通过 proxies 参数
    """
    proxies = None
    if proxy_cfg and proxy_cfg.get("enabled"):
        url = _build_proxy_url(proxy_cfg)
        if url:
            proxies = {"https": url, "http": url}
    
    from deep_translator import GoogleTranslator
    if proxies:
        return GoogleTranslator(source="zh-CN", target=target, proxies=proxies).translate(text)
    return GoogleTranslator(source="zh-CN", target=target).translate(text)


# ──────────────────────────────────────────────────────────
#  2. DeepL 官方 API (需要 key)
# ──────────────────────────────────────────────────────────
DEEPL_LANG = {"en": "EN-US", "ja": "JA", "ko": "KO"}


def _deepl(text: str, target: str, api_key: str, proxy_url: str = None) -> str:
    tgt = DEEPL_LANG.get(target, target.upper())
    with _get_httpx_client(proxy_url) as client:
        resp = client.post(
            "https://api-free.deepl.com/v2/translate",
            data={"auth_key": api_key, "text": text, "source_lang": "ZH",
                  "target_lang": tgt},
        )
        resp.raise_for_status()
        return resp.json()["translations"][0]["text"]


# ──────────────────────────────────────────────────────────
#  3. 百度翻译 API
# ──────────────────────────────────────────────────────────
BAIDU_LANG = {"en": "en", "ja": "jp", "ko": "kor"}


def _baidu(text: str, target: str, appid: str, secret: str, proxy_url: str = None) -> str:
    salt = str(random.randint(10000, 99999))
    sign_raw = appid + text + salt + secret
    sign = hashlib.md5(sign_raw.encode()).hexdigest()
    tgt = BAIDU_LANG.get(target, target)
    with _get_httpx_client(proxy_url) as client:
        resp = client.get(
            "https://fanyi-api.baidu.com/api/trans/vip/translate",
            params={"q": text, "from": "zh", "to": tgt,
                    "appid": appid, "salt": salt, "sign": sign},
        )
        resp.raise_for_status()
        data = resp.json()
        if "trans_result" in data:
            return data["trans_result"][0]["dst"]
        raise RuntimeError(f"Baidu error: {data}")


# ──────────────────────────────────────────────────────────
#  4. 有道翻译 API (v3 HMAC-SHA256)
# ──────────────────────────────────────────────────────────
import hmac, base64

YOUDAO_LANG = {"en": "en", "ja": "ja", "ko": "ko"}


def _youdao(text: str, target: str, appkey: str, secret: str, proxy_url: str = None) -> str:
    import uuid
    tgt = YOUDAO_LANG.get(target, target)
    curtime = str(int(time.time()))
    salt = str(uuid.uuid4())
    sign_str = appkey + _truncate(text) + salt + curtime + secret
    sign = hashlib.sha256(sign_str.encode("utf-8")).hexdigest()
    with _get_httpx_client(proxy_url) as client:
        resp = client.post(
            "https://openapi.youdao.com/api",
            data={"q": text, "from": "zh-CHS", "to": tgt,
                  "appKey": appkey, "salt": salt, "sign": sign,
                  "signType": "v3", "curtime": curtime},
        )
        resp.raise_for_status()
        data = resp.json()
        if data.get("errorCode") == "0":
            return data["translation"][0]
        raise RuntimeError(f"Youdao error: {data}")


def _truncate(text: str) -> str:
    if len(text) <= 20:
        return text
    return text[:10] + str(len(text)) + text[-10:]


# ──────────────────────────────────────────────────────────
#  5. Microsoft Azure Translator
# ──────────────────────────────────────────────────────────
MS_LANG = {"en": "en", "ja": "ja", "ko": "ko"}


def _microsoft(text: str, target: str, key: str, region: str = "eastasia", proxy_url: str = None) -> str:
    tgt = MS_LANG.get(target, target)
    with _get_httpx_client(proxy_url) as client:
        resp = client.post(
            "https://api.cognitive.microsofttranslator.com/translate",
            params={"api-version": "3.0", "from": "zh-Hans", "to": tgt},
            headers={"Ocp-Apim-Subscription-Key": key,
                     "Ocp-Apim-Subscription-Region": region,
                     "Content-Type": "application/json"},
            json=[{"text": text}],
        )
        resp.raise_for_status()
        return resp.json()[0]["translations"][0]["text"]


# ──────────────────────────────────────────────────────────
#  统一调用入口
# ──────────────────────────────────────────────────────────
API_LIST = [
    "deep_translator_google",  # ← 主推，免费稳定
    "deepl",                   # 需要Key
    "baidu",                   # 需要Key
    "youdao",                  # 需要Key
    "microsoft",               # 需要Key
]

def translate(text: str, targets: list[str], api: str, cfg: dict) -> dict[str, str]:
    """
    targets: ["en","ja","ko"]
    api: API_LIST 中的一个
    cfg: settings["api_keys"]
    cfg["proxy"]: 代理配置 {"enabled": true, "type": "http"|"socks5", "host": "...", "port": ..., "user"?, "password"?}
    返回 {"en": "...", "ja": "...", "ko": "..."}
    """
    results = {}
    proxy_cfg = cfg.get("proxy", {})
    proxy_url = _build_proxy_url(proxy_cfg)
    
    for tgt in targets:
        try:
            if api == "deep_translator_google":
                results[tgt] = _deep_translator_google(text, tgt, proxy_cfg)
            elif api == "deepl":
                results[tgt] = _deepl(text, tgt, cfg.get("deepl", ""), proxy_url)
            elif api == "baidu":
                results[tgt] = _baidu(text, tgt,
                                       cfg.get("baidu_appid", ""),
                                       cfg.get("baidu_secret", ""),
                                       proxy_url)
            elif api == "youdao":
                results[tgt] = _youdao(text, tgt,
                                        cfg.get("youdao_appkey", ""),
                                        cfg.get("youdao_secret", ""),
                                        proxy_url)
            elif api == "microsoft":
                results[tgt] = _microsoft(text, tgt,
                                           cfg.get("microsoft_key", ""),
                                           cfg.get("microsoft_region", "eastasia"),
                                           proxy_url)
            else:
                results[tgt] = f"[未知API: {api}]"
        except Exception as e:
            logger.warning(f"translate [{api}] {tgt} error: {e}")
            results[tgt] = f"[翻译失败: {e}]"
    return results
