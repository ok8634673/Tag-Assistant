# 短视频助手

一款基于 Flet 的多平台短视频标题/Tag 管理工具，支持自动翻译、Tag 补全、局域网协助 API。

## 功能特性

- 📕 **多平台支持**：小红书(50个Tag) / 抖音(5个) / 快手(4个) / 得物(5个)
- 🌐 **三语自动翻译**：中→英/日/韩，支持6种翻译 API 切换
- ✨ **标题自动组合**：角色名の主题 格式，下拉选择快速组合
- 🏷️ **Tag 智能填充**：活动Tag + 填充预设组合，一键填入多平台
- 🎨 **可视化Tag管理**：黄色标签样式填充预设，绿色标签样式活动Tag
- 💾 **状态自动记忆**：Tab切换、重启软件后保留Tag方案，方便细调
- 🔌 **局域网协助 API**：AI 助手可通过 HTTP API 远程控制、读取状态、协助除错
- 📦 **导出/导入**：所有设置和预设可导出为 JSON，换机迁移方便
- 🗂️ **预设管理**：角色名、主题、Tag库、填充预设均可增删编辑

## 快速启动

```bash
# 安装依赖
pip install flet deep-translator flask flask-cors httpx

# 运行
python main.py
```

## 依赖

| 包 | 用途 |
|---|---|
| flet | GUI 框架 |
| deep-translator | Google 翻译（免费） |
| flask / flask-cors | 协助 API 服务器 |
| httpx | HTTP 客户端（DeepL/百度/有道/微软翻译） |

## 翻译 API 支持

| API | 是否需要密钥 | 备注 |
|---|---|---|
| deep_translator_google | ❌ 免费 | 默认，推荐 |
| deepl | ✅ | 需要 DeepL Free API Key |
| baidu | ✅ | 百度翻译开放平台 |
| youdao | ✅ | 有道智云 |
| microsoft | ✅ | Azure 认知服务 |

## 协助 API

默认监听 `0.0.0.0:8765`，局域网内其他设备（或 AI 助手）可访问。

### 核心接口

| 接口 | 方法 | 说明 |
|------|------|------|
| `/api/assistant/inputs` | GET | 获取活动Tag输入框和填充预设选择状态 |
| `/api/assistant/click_tag` | POST | 点击Tag按钮，自动填入活动Tag和填充预设 |
| `/api/assistant/add_fill_preset` | POST | 新增填充预设行并选中指定预设 |
| `/api/state` | GET | 获取所有平台标题和Tag状态 |
| `/api/tags/{platform}` | POST | 设置指定平台Tag |
| `/api/title/{platform}/{lang}` | POST | 设置指定平台标题 |

完整接口文档详见 [API文档.md](./API文档.md)

## 助手Tab功能

助手Tab是核心工作区，提供高效的Tag管理方案：

- **活动Tag输入框**（绿色标签）：填入平台活动Tag，支持多行输入
- **填充预设下拉框**（黄色标签）：选择预设Tag组合，一键填入
- **Tag方案记忆**：自动保存当前组合，重启后恢复，方便细调
- **智能填充顺序**：活动Tag优先 → 填充预设Tag → 自动补全

### 使用示例

1. 在活动Tag输入框填入 `我的春天时刻`
2. 选择填充预设 `AI预设`（包含 AI、人工智能）
3. 点击Tag按钮，自动填入：`我的春天时刻 AI 人工智能`
4. 切换Tab或重启软件，配置自动保留

## 文件结构

```
短视频助手/
├── main.py              # 主程序（Flet GUI）
├── translator.py        # 多 API 翻译模块
├── assist_api.py        # 局域网协助 API 服务
├── data/
│   ├── presets.json     # 预设（角色/主题/Tag库/填充预设）
│   └── settings.json    # 设置（翻译API/协助API配置/Tab状态）
├── API文档.md
└── README.md
```

## 更新日志

### v1.x (2026-04-20)
- 📝 **标题Tag空行分隔**：点击Tag按钮后，标题和Tag之间自动隔一行，排版更清晰
- 🏷️ **预设支持每行一个Tag**：填充预设可设置"每行一个"，活动类标签独立成行
- 🏷️ **Tag 智能排版**：活动Tag独立成行，填充预设分组换行，舒适排版规律
- 🔧 **修复排版覆盖问题**：调整执行顺序，确保分组排版不被 `do_auto_tags` 覆盖
- 🔧 **修复预设元数据丢失**：修复下拉框显示格式包含`：`时，`newline_per_tag`设置不生效的问题
- 💾 **增强状态记忆**：软件重启后自动恢复下拉框选择，无需手动刷新
- 🔄 **新增 API**：`replace_preset` 动态替换已选预设
- 🐛 **修复Tag导入**：支持批量导入带`#`前缀的Tag，编辑预设时不再丢失已有Tag

### v1.x (2026-04-16)
- ✨ 新增助手Tab Tag预设功能（活动Tag + 填充预设组合）
- ✨ 新增协助API：读取助手状态、点击Tag按钮、添加填充预设
- 🎨 优化UI：黄色标签样式填充预设，绿色标签样式活动Tag
- 💾 新增状态记忆：Tab切换、重启后保留Tag方案
- 🐛 修复：函数定义顺序导致的API调用错误
