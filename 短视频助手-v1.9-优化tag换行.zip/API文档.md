# 短视频助手 API 文档

## 协助 API（局域网）

**基础地址：** `http://<主机IP>:8765`

### 鉴权
在请求头中添加 `X-Token: <your_token>`（设置页面配置；为空时不需要鉴权）

---

### GET /api/ping
测试连通性

**响应示例：**
```json
{"pong": true, "service": "ShortVideoAssistant"}
```

---

### GET /api/console
读取最近调试日志（供 AI 助手除错）

**参数：** `?n=100` 返回条数（默认100，上限500）

**响应示例：**
```json
{
  "lines": [
    "[12:02:14] [Tab切换] -> assistant  tab_fields包含平台: ['xiaohongshu', 'douyin', 'kuaishou', 'dewu']",
    "[12:03:01] [全部Tag] 当前tab=assistant 目标平台=['xiaohongshu']",
    "[12:03:01] [自动Tag] xiaohongshu 成功，共 50 个tag"
  ],
  "count": 3
}
```

---

### POST /api/console/clear
清空调试日志缓冲区

**响应示例：** `{"ok": true}`

---

### GET /api/state
获取当前所有平台的标题和 Tag 状态

**响应示例：**
```json
{
  "xiaohongshu": {
    "titles": {"zh": "蓝砚の日常", "en": "Lanyan's Daily", "ja": "蓝砚の日常", "ko": ""},
    "tags": ["原神", "二次元", "同人"]
  },
  "douyin": { "titles": {...}, "tags": [...] },
  "kuaishou": { ... },
  "dewu": { ... }
}
```

---

### GET /api/assistant/inputs
获取助手Tab的活动Tag输入框和填充预设选择状态

**响应示例：**
```json
{
  "xiaohongshu": {
    "activity_tags": ["春日活动", "新品上市"],
    "fill_presets": [
      {"type": "dropdown", "value": "AI相关：AI 人工智能 科技"},
      {"type": "textfield", "value": "自定义标签"}
    ]
  },
  "douyin": { "activity_tags": [], "fill_presets": [] },
  "kuaishou": { ... },
  "dewu": { ... }
}
```

---

### POST /api/assistant/click_tag
点击指定平台的Tag按钮（自动填入活动Tag和填充预设）

**请求体：**
```json
{"platform": "xiaohongshu"}
```

**platform:** `xiaohongshu` / `douyin` / `kuaishou` / `dewu`

**响应示例：**
```json
{"ok": true, "message": "已触发 xiaohongshu 的Tag按钮"}
```

---

### POST /api/assistant/add_fill_preset
为指定平台新增一行填充预设下拉框，或在现有下拉框中选择预设

**两种用法：**

#### 1. 新增空预设行（点击"增加预设"按钮）
**请求体：**
```json
{"platform": "xiaohongshu"}
```

**响应示例：**
```json
{"ok": true, "message": "已添加空的预设行，请手动选择预设"}
```

#### 2. 在新添加的下拉框中选择预设
**请求体：**
```json
{"platform": "xiaohongshu", "preset_name": "AI"}
```

**platform:** `xiaohongshu` / `douyin` / `kuaishou` / `dewu`
**preset_name:** 预设名称（如"AI"、"test"等，需在填充预设列表中存在）

**选择逻辑：**
- 优先在**最新添加的、尚未选择预设**的下拉框中设置值
- 如果没有空的下拉框，则在**顶部**的下拉框中设置
- 如果都没有，则新建一个下拉框并设置值

**响应示例：**
```json
{"ok": true, "message": "已在新添加的下拉框中选择预设 AI"}
```

---

### POST /api/assistant/remove_fill_preset
删除指定平台中已选中的预设下拉框

**请求体：**
```json
{"platform": "xiaohongshu", "preset_name": "123"}
```

**platform:** `xiaohongshu` / `douyin` / `kuaishou` / `dewu`
**preset_name:** 要删除的预设名称

**响应示例：**
```json
{"ok": true, "message": "已删除预设 123"}
```

---

### POST /api/assistant/replace_preset
替换指定平台中已选中的预设

**请求体：**
```json
{"platform": "xiaohongshu", "old_preset": "AI", "new_preset": "test"}
```

**platform:** `xiaohongshu` / `douyin` / `kuaishou` / `dewu`
**old_preset:** 原预设名称
**new_preset:** 新预设名称

**响应示例：**
```json
{"ok": true, "message": "已将顶部 AI 替换为 test"}
```

#### 完整操作流程示例

**场景1：添加两个预设并点击Tag按钮**

```python
import requests

BASE = "http://localhost:8765"

# 1. 点击"增加预设"按钮（新增空下拉框）
requests.post(f"{BASE}/api/assistant/add_fill_preset", 
              json={"platform": "xiaohongshu"})

# 2. 在新添加的下拉框中选择"数字测试"预设
requests.post(f"{BASE}/api/assistant/add_fill_preset", 
              json={"platform": "xiaohongshu", "preset_name": "数字测试"})

# 3. 再次点击"增加预设"按钮（新增第二个空下拉框）
requests.post(f"{BASE}/api/assistant/add_fill_preset", 
              json={"platform": "xiaohongshu"})

# 4. 选择"123"预设
requests.post(f"{BASE}/api/assistant/add_fill_preset", 
              json={"platform": "xiaohongshu", "preset_name": "123"})

# 5. 点击Tag按钮（填入所有预设的Tag）
requests.post(f"{BASE}/api/assistant/click_tag", 
              json={"platform": "xiaohongshu"})
```

**场景2：替换预设并删除不需要的预设**

```python
import requests

BASE = "http://localhost:8765"

# 1. 将"AI"预设替换为"test"
requests.post(f"{BASE}/api/assistant/replace_preset", 
              json={"platform": "xiaohongshu", "old_preset": "AI", "new_preset": "test"})

# 2. 将"数字测试"预设替换为"test2"
requests.post(f"{BASE}/api/assistant/replace_preset", 
              json={"platform": "xiaohongshu", "old_preset": "数字测试", "new_preset": "test2"})

# 3. 删除"123"预设
requests.post(f"{BASE}/api/assistant/remove_fill_preset", 
              json={"platform": "xiaohongshu", "preset_name": "123"})

# 4. 点击Tag按钮更新Tag内容
requests.post(f"{BASE}/api/assistant/click_tag", 
              json={"platform": "xiaohongshu"})

# 5. 点击Tag按钮（填入所有预设的Tag）
requests.post(f"{BASE}/api/assistant/click_tag", 
              json={"platform": "xiaohongshu"})
```

**注意：** 使用中文预设名时，建议用 Python `requests` 库调用，PowerShell 可能存在编码问题。

---

### POST /api/tags/{platform}
设置指定平台的 Tag 列表

**platform:** `xiaohongshu` / `douyin` / `kuaishou` / `dewu`

**请求体：**
```json
{"tags": ["原神", "二次元", "同人"]}
```

**限制：** 每个平台 Tag 数量上限（小红书50 / 抖音5 / 快手4 / 得物5）

---

### POST /api/title/{platform}/{lang}
设置指定平台+语言的标题

**lang:** `zh` / `en` / `ja` / `ko`

**请求体：**
```json
{"text": "Lanyan's Daily Life"}
```

---

### POST /api/tags/suggest
根据关键词推荐 Tag

**请求体：**
```json
{"keyword": "原神"}
```

**响应：**
```json
{"suggestions": ["原神", "原神玩家", "原神同人", "genshinimpact"]}
```

---

### POST /api/apply_all
批量更新所有平台（AI 助手使用此接口一次性推送）

**请求体：**
```json
{
  "titles": {
    "xiaohongshu": {
      "zh": "蓝砚の日常",
      "en": "Lanyan's Daily Life",
      "ja": "蓝砚の日常",
      "ko": "남선의 일상"
    }
  },
  "tags": {
    "xiaohongshu": ["原神", "二次元", "日常", "角色", "同人"],
    "douyin": ["原神", "二次元", "同人"]
  }
}
```

---

## 使用示例（Python）

```python
import httpx

BASE = "http://192.168.1.100:8765"
HEADERS = {"X-Token": "your_token"}  # 无token可省略

# 获取状态
state = httpx.get(f"{BASE}/api/state", headers=HEADERS).json()

# 批量更新
httpx.post(f"{BASE}/api/apply_all", headers=HEADERS, json={
    "titles": {
        "xiaohongshu": {"zh": "可莉の冒险日记", "en": "Klee's Adventure Diary"}
    },
    "tags": {
        "xiaohongshu": ["原神", "可莉", "冒险", "二次元", "游戏"],
        "douyin": ["原神", "可莉", "二次元"]
    }
})
```
