"""
assist_api.py — 局域网协助 API 服务
AI 助手可通过此 API 协助补全 Tag、校对翻译、编辑标题、读取调试日志
"""
import threading, logging, json
from collections import deque
from flask import Flask, request, jsonify
from flask_cors import CORS

logger = logging.getLogger("assist_api")
_app = Flask(__name__)
CORS(_app)

# ── 全局回调（由主程序注册）────────────────────────────────────────
_callbacks = {
    "get_state": None,       # () -> dict
    "update_tags": None,     # (platform, tags: list) -> None
    "update_title": None,    # (platform, lang, text) -> None
    "suggest_tags": None,    # (keyword) -> list[str]
    "get_presets": None,     # () -> dict（获取所有预设）
    "get_inputs": None,       # () -> dict（获取当前输入框内容）
    "set_activity_tags": None, # (platform, activity_tags: list) -> None
    "auto_tags": None,         # (platform) -> None（自动填充 Tag）
    "get_assistant_inputs": None,  # () -> dict（获取助手Tab输入状态）
    "click_tag_button": None,      # (platform) -> dict（点击Tag按钮）
    "add_fill_preset": None,       # (platform, preset_name) -> dict（新增填充预设行）
    "remove_fill_preset": None,    # (platform, preset_name) -> dict（删除指定预设行）
    "combo_apply": None,           # () -> dict（组合并应用：角色+主题填入所有平台）
    "save_tag_scheme_preset": None,  # (data) -> dict（保存Tag方案预设）
}

# ── 内存日志收集器（最多保留最新 N 条，供 API 读取）──────────────
_log_buffer: deque[str] = deque(maxlen=500)
_log_lock = threading.Lock()

def api_log(msg: str):
    """主程序可调用此函数将消息写入日志缓冲区"""
    ts = __import__("datetime").datetime.now().strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    with _log_lock:
        _log_buffer.append(line)

_token = ""  # 空表示不鉴权

def _auth():
    if not _token:
        return True
    return request.headers.get("X-Token") == _token

# ──────────────────────────────────────────────────────────
#  路由
# ──────────────────────────────────────────────────────────
@_app.get("/api/state")
def api_state():
    """获取当前所有平台的标题和 Tag"""
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    if _callbacks["get_state"]:
        return jsonify(_callbacks["get_state"]())
    return jsonify({"error": "not ready"}), 503

@_app.post("/api/tags/<platform>")
def api_set_tags(platform):
    """
    设置指定平台 Tag
    body: {"tags": ["tag1","tag2",...]}
    """
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json(silent=True) or {}
    tags = data.get("tags", [])
    if not isinstance(tags, list):
        return jsonify({"error": "tags must be list"}), 400
    if _callbacks["update_tags"]:
        _callbacks["update_tags"](platform, tags)
        return jsonify({"ok": True, "platform": platform, "tags": tags})
    return jsonify({"error": "not ready"}), 503

@_app.post("/api/title/<platform>/<lang>")
def api_set_title(platform, lang):
    """
    设置指定平台+语言标题
    body: {"text": "..."}
    lang: zh / en / ja / ko
    """
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json(silent=True) or {}
    text = data.get("text", "")
    if _callbacks["update_title"]:
        _callbacks["update_title"](platform, lang, text)
        return jsonify({"ok": True})
    return jsonify({"error": "not ready"}), 503

@_app.post("/api/tags/suggest")
def api_suggest_tags():
    """
    根据关键词建议 Tag
    body: {"keyword": "..."}
    """
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json(silent=True) or {}
    keyword = data.get("keyword", "")
    if _callbacks["suggest_tags"]:
        suggestions = _callbacks["suggest_tags"](keyword)
        return jsonify({"suggestions": suggestions})
    return jsonify({"suggestions": []})

@_app.post("/api/apply_all")
def api_apply_all():
    """
    批量更新所有平台
    body: {
      "titles": {"xiaohongshu": {"zh":"..","en":"..","ja":"..","ko":".."},..},
      "tags": {"xiaohongshu": [...], "douyin": [...], ...}
    }
    """
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json(silent=True) or {}
    applied = []
    for plat, langs in (data.get("titles") or {}).items():
        for lang, text in langs.items():
            if _callbacks["update_title"]:
                _callbacks["update_title"](plat, lang, text)
                applied.append(f"title/{plat}/{lang}")
    for plat, tags in (data.get("tags") or {}).items():
        if _callbacks["update_tags"]:
            _callbacks["update_tags"](plat, tags)
            applied.append(f"tags/{plat}")
    return jsonify({"ok": True, "applied": applied})

@_app.get("/api/console")
def api_console():
    """
    读取最近的调试日志（供 AI 助手除错用）
    ?n=100  指定返回条数（默认100，上限500）
    """
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    try:
        n = min(int(request.args.get("n", 100)), 500)
    except ValueError:
        n = 100
    with _log_lock:
        lines = list(_log_buffer)[-n:]
    return jsonify({"lines": lines, "count": len(lines)})

@_app.post("/api/console/clear")
def api_console_clear():
    """清空日志缓冲区"""
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    with _log_lock:
        _log_buffer.clear()
    return jsonify({"ok": True})

@_app.get("/api/inputs")
def api_inputs():
    """读取当前输入框内容（角色+主题，实时）"""
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    if _callbacks["get_inputs"]:
        return jsonify(_callbacks["get_inputs"]())
    return jsonify({"character": "", "theme": ""})

@_app.get("/api/assistant/inputs")
def api_assistant_inputs():
    """读取助手Tab的活动Tag输入框和填充预设选择状态"""
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    if _callbacks["get_assistant_inputs"]:
        return jsonify(_callbacks["get_assistant_inputs"]())
    return jsonify({"error": "not ready"}), 503

@_app.post("/api/assistant/save_tag_scheme_preset")
def api_assistant_save_tag_scheme():
    """保存Tag方案预设
    body: {"platform": "xiaohongshu", "name": "方案名称"}  # name可选
    """
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json(silent=True) or {}
    if _callbacks.get("save_tag_scheme_preset"):
        result = _callbacks["save_tag_scheme_preset"](data)
        return jsonify(result)
    return jsonify({"error": "not ready"}), 503

@_app.post("/api/assistant/click_tag")
def api_assistant_click_tag():
    """点击指定平台的Tag按钮（自动填入活动Tag和填充预设）"""
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json(silent=True) or {}
    platform = data.get("platform")
    if not platform:
        return jsonify({"error": "platform is required"}), 400
    if _callbacks["click_tag_button"]:
        result = _callbacks["click_tag_button"](platform)
        return jsonify(result)
    return jsonify({"error": "not ready"}), 503

@_app.post("/api/assistant/add_fill_preset")
def api_assistant_add_fill_preset():
    """为指定平台新增一行填充预设下拉框
    body: {"platform": "xiaohongshu", "preset_name": "test"}  # 有preset_name则选中该预设
    body: {"platform": "xiaohongshu"}  # 无preset_name则创建空的dropdown让用户选择
    """
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json(silent=True) or {}
    platform = data.get("platform")
    preset_name = data.get("preset_name")  # 可选，不传则创建空dropdown
    if not platform:
        return jsonify({"error": "platform is required"}), 400
    if _callbacks.get("add_fill_preset"):
        result = _callbacks["add_fill_preset"](platform, preset_name)
        return jsonify(result)
    return jsonify({"error": "not ready"}), 503


@_app.post("/api/assistant/remove_fill_preset")
def api_assistant_remove_fill_preset():
    """删除指定平台中已选中的预设下拉框
    body: {"platform": "xiaohongshu", "preset_name": "test2"}
    返回: {"ok": true, "message": "已删除预设 test2"}
    """
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json(silent=True) or {}
    platform = data.get("platform")
    preset_name = data.get("preset_name")
    if not platform:
        return jsonify({"error": "platform is required"}), 400
    if not preset_name:
        return jsonify({"error": "preset_name is required"}), 400
    if _callbacks.get("remove_fill_preset"):
        result = _callbacks["remove_fill_preset"](platform, preset_name)
        return jsonify(result)
    return jsonify({"error": "not ready"}), 503


@_app.post("/api/assistant/replace_preset")
def api_assistant_replace_preset():
    """替换指定平台中已选中的预设
    body: {"platform": "xiaohongshu", "old_preset": "test", "new_preset": "数字测试"}
    返回: {"ok": true, "message": "已将 test 替换为 数字测试"}
    """
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json(silent=True) or {}
    platform = data.get("platform")
    old_preset = data.get("old_preset")
    new_preset = data.get("new_preset")
    if not platform:
        return jsonify({"error": "platform is required"}), 400
    if not old_preset or not new_preset:
        return jsonify({"error": "old_preset and new_preset are required"}), 400
    if _callbacks.get("replace_preset"):
        result = _callbacks["replace_preset"](platform, old_preset, new_preset)
        return jsonify(result)
    return jsonify({"error": "not ready"}), 503


@_app.post("/api/combo_apply")
def api_combo_apply():
    """组合并应用：将角色+主题组合成标题，填入所有平台，自动翻译
    body: {}（无需参数，使用当前输入区的角色和主题）
    返回: {"ok": true, "message": "已组合并应用: 月桂の依赖摇", "composed": "月桂の依赖摇"}
    """
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    if _callbacks.get("combo_apply"):
        result = _callbacks["combo_apply"]()
        return jsonify(result)
    return jsonify({"error": "not ready"}), 503

@_app.get("/api/dev_logs")
def api_dev_logs():
    """读取开发者日志和开关状态"""
    cb = _callbacks.get("get_dev_logs")
    if cb:
        return jsonify(cb())
    return jsonify({"open": False, "lines": [], "error": "not ready"}), 503

@_app.get("/api/observe_ui")
def api_observe_ui():
    """观察 UI 状态，包括下拉框选项数量"""
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    cb = _callbacks.get("observe_ui")
    if cb:
        return jsonify(cb())
    return jsonify({"error": "not ready"}), 503

@_app.get("/api/ping")
def api_ping():
    return jsonify({"pong": True, "service": "ShortVideoAssistant"})

@_app.get("/api/presets")
def api_presets():
    """获取所有预设数据"""
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    if _callbacks["get_presets"]:
        return jsonify(_callbacks["get_presets"]())
    return jsonify({"error": "not ready"}), 503

@_app.post("/api/set_character")
def api_set_character():
    """写入角色名到各平台编辑框"""
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json() or {}
    char = data.get("character", "").strip()
    platform = data.get("platform")  # None = 所有平台
    if _callbacks["set_character"]:
        _callbacks["set_character"](char, platform)
        return jsonify({"ok": True, "character": char})
    return jsonify({"error": "not ready"}), 503

@_app.post("/api/set_theme")
def api_set_theme():
    """写入主题到各平台编辑框"""
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json() or {}
    theme = data.get("theme", "").strip()
    platform = data.get("platform")  # None = 所有平台
    if _callbacks["set_theme"]:
        _callbacks["set_theme"](theme, platform)
        return jsonify({"ok": True, "theme": theme})
    return jsonify({"error": "not ready"}), 503

@_app.post("/api/set_activity_tags")
def api_set_activity_tags():
    """填入活动Tag到指定平台"""
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json() or {}
    platform = data.get("platform")
    activity_tags = data.get("activity_tags", [])
    if not isinstance(activity_tags, list):
        return jsonify({"error": "activity_tags must be list"}), 400
    if _callbacks.get("set_activity_tags"):
        _callbacks["set_activity_tags"](platform, activity_tags)
        return jsonify({"ok": True, "platform": platform, "activity_tags": activity_tags})
    return jsonify({"error": "not ready"}), 503

@_app.post("/api/auto_tags")
def api_auto_tags():
    """自动填充 Tag（从默认库补满槽位）"""
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json() or {}
    platform = data.get("platform")
    if _callbacks.get("auto_tags"):
        _callbacks["auto_tags"](platform)
        return jsonify({"ok": True, "platform": platform})
    return jsonify({"error": "not ready"}), 503

@_app.post("/api/translate")
def api_translate():
    """对标题进行翻译（使用预设或API）"""
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json() or {}
    char = data.get("character", "").strip()
    theme = data.get("theme", "").strip()
    platform = data.get("platform")  # None = 所有平台
    targets = data.get("targets", ["en", "ja", "ko"])
    if _callbacks["translate"]:
        _callbacks["translate"](char, theme, platform, targets)
        return jsonify({"ok": True})
    return jsonify({"error": "not ready"}), 503

@_app.post("/api/update_title")
def api_update_title():
    """更新指定平台的标题行（单行）"""
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json() or {}
    platform = data.get("platform")
    lang = data.get("lang", "en")
    text = data.get("text", "")
    if _callbacks["update_title"]:
        _callbacks["update_title"](platform, lang, text)
        return jsonify({"ok": True})
    return jsonify({"error": "not ready"}), 503

@_app.post("/api/update_tags")
def api_update_tags():
    """追加标签到指定平台"""
    if not _auth():
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json() or {}
    platform = data.get("platform")
    tags = data.get("tags", [])
    if _callbacks["update_tags"]:
        _callbacks["update_tags"](platform, tags)
        return jsonify({"ok": True})
    return jsonify({"error": "not ready"}), 503

# ──────────────────────────────────────────────────────────
#  启动 / 停止
# ──────────────────────────────────────────────────────────
_server_thread: threading.Thread | None = None

def register(name: str, fn):
    _callbacks[name] = fn

def start(host="0.0.0.0", port=8765, token=""):
    global _server_thread, _token
    _token = token
    _server_thread = threading.Thread(
        target=lambda: _app.run(host=host, port=port, use_reloader=False, threaded=True),
        daemon=True,
        name="AssistAPIServer",
    )
    _server_thread.start()
    logger.info(f"Assist API running on {host}:{port}")

def is_running() -> bool:
    return _server_thread is not None and _server_thread.is_alive()
