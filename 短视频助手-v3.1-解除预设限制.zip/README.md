# 短视频助手

一款基于 [Flet](https://flet.dev) 构建的桌面应用，面向多平台短视频创作者，提供标题/Tag 智能管理、三语自动翻译、填充预设组合等功能，并内置局域网协助 API，可由 AI 助手远程控制。

## 功能特性

- 📕 **多平台支持**：小红书(50 Tag) / 抖音(5) / 快手(4) / 得物(5)，各平台独立配置
- 🌐 **三语自动翻译**：中文标题 → 英/日/韩，支持 6 种翻译 API 切换
- ✨ **标题自动组合**：`角色名の主题` 格式，下拉选择快速组合
- 🏷️ **Tag 智能填充**：活动 Tag + 填充预设组合，一键填入多平台
- 🎨 **可视化 Tag 管理**：黄色标签样式填充预设，绿色标签样式活动 Tag
- 💾 **状态自动记忆**：Tab 切换、重启软件后保留 Tag 方案，方便细调
- 🔌 **局域网协助 API**：AI 助手可通过 HTTP API 远程控制、读取状态、协助排错
- 📦 **导出/导入**：所有设置和预设可导出为 JSON，换机迁移方便
- 🗂️ **预设管理**：角色名、主题、Tag 库、填充预设均可增删编辑

## 安装

```bash
# 克隆仓库
git clone https://github.com/yourusername/short-video-assistant.git
cd short-video-assistant

# 安装依赖（Python 3.10+）
pip install -r requirements.txt

# 运行
python main.py
```

## 依赖

| 包 | 版本要求 | 用途 |
|---|---|---|
| flet | >=0.24.0, <0.81.0 | GUI 框架 |
| deep-translator | >=1.11.4 | Google 翻译（免费，默认） |
| flask | >=2.3.0 | 协助 API 服务器 |
| flask-cors | >=4.0.0 | 跨域支持 |
| httpx | >=0.27.0 | HTTP 客户端（DeepL/百度/有道/微软翻译） |
| pyperclip | >=1.8.2 | 剪贴板操作（复制/粘贴） |

## 配置

首次运行会自动在 `data/` 目录下生成 `settings.json`，可在 UI 中修改：

- **翻译 API**：支持 DeepL / 百度 / 有道 / 微软，填写对应 API Key 即可切换
- **代理设置**：支持 SOCKS5 / HTTP 代理
- **协助 API**：默认监听 `0.0.0.0:8765`，可在设置中修改 host/port

## 翻译 API 支持

| API | 是否需要密钥 | 备注 |
|---|---|---|
| deep_translator_google | ❌ 免费 | 默认，推荐 |
| deepl | ✅ | 需要 DeepL Free API Key |
| baidu | ✅ | 百度翻译开放平台 |
| youdao | ✅ | 有道智云 |
| microsoft | ✅ | Azure 认知服务 |

## 协助 API

默认监听 `0.0.0.0:8765`，局域网内其他设备（或 AI 助手）可访问。

### 核心接口

| 接口 | 方法 | 说明 |
|------|------|------|
| `/api/assistant/inputs` | GET | 获取活动 Tag 输入框和填充预设选择状态 |
| `/api/assistant/click_tag` | POST | 点击 Tag 按钮，自动填入活动 Tag 和填充预设 |
| `/api/assistant/add_fill_preset` | POST | 新增填充预设行并选中指定预设 |
| `/api/state` | GET | 获取所有平台标题和 Tag 状态 |
| `/api/tags/{platform}` | POST | 设置指定平台 Tag |
| `/api/title/{platform}/{lang}` | POST | 设置指定平台标题 |

完整接口文档详见 [API文档.md](./API文档.md)

## 助手 Tab 功能

助手 Tab 是核心工作区，提供高效的 Tag 管理方案：

- **活动 Tag 输入框**（绿色标签）：填入平台活动 Tag，支持多行输入
- **填充预设下拉框**（黄色标签）：选择预设 Tag 组合，一键填入
- **自定义排序预设**：保存/加载编辑区控件的完整布局，支持拖拽排序
- **Tag 方案记忆**：自动保存当前组合，重启后恢复，方便细调
- **智能填充顺序**：活动 Tag 优先 → 填充预设 Tag → 自动补全

### 使用示例

1. 在活动 Tag 输入框填入 `我的春天时刻`
2. 选择填充预设 `AI预设`（包含 AI、人工智能）
3. 点击 Tag 按钮，自动填入：`#我的春天时刻 #AI #人工智能`
4. 切换 Tab 或重启软件，配置自动保留

## 文件结构

```
短视频助手/
├── main.py                # 主程序（Flet GUI）
├── translator.py          # 多 API 翻译模块
├── assist_api.py          # 局域网协助 API 服务
├── data/
│   ├── presets.json      # 预设（角色/主题/Tag库/填充预设/排序预设）
│   └── settings.json     # 设置（翻译API/协助API配置/Tab状态）
├── API文档.md            # 协助 API 完整文档
├── requirements.txt       # Python 依赖
└── README.md
```

> ⚠️ `data/settings.json` 和 `data/presets.json` 包含个人数据，请勿提交到公开仓库。

## 更新日志

### v1.x (2026-05-18)
- 🏷️ **自定义排序预设增强**：保存编辑区完整控件结构（含多个下拉框），加载时完整还原
- 💾 **顶部下拉框记忆修复**：重启后正确恢复填充预设顶部下拉框选择
- 🐛 **修复排序预设来源预设丢失**：保存时记录 `edit_area_controls`，加载时完整还原

### v1.x (2026-04-20)
- 📋 **编辑区复制/粘贴按钮**：为每个平台的编辑区添加剪贴板操作按钮
- ✨ **一键补全功能**：粘贴文案后点击"✨补全"按钮自动翻译标题并填充 Tag 预设
- 📝 **标题Tag空行分隔**：点击 Tag 按钮后，标题和 Tag 之间自动隔一行
- 🏷️ **Tag 智能排版**：活动 Tag 独立成行，填充预设分组换行

### v1.x (2026-04-16)
- ✨ 新增助手 Tab Tag 预设功能（活动 Tag + 填充预设组合）
- ✨ 新增协助 API：读取助手状态、点击 Tag 按钮、添加填充预设
- 💾 新增状态记忆：Tab 切换、重启后保留 Tag 方案

## License

MIT License —— 详情见 [LICENSE](./LICENSE)（待添加）

## 致谢

- [Flet](https://flet.dev) - 跨平台 GUI 框架
- [deep-translator](https://github.com/nidhaloff/deep-translator) - 多引擎翻译
- [Flask](https://flask.palletsprojects.com/) - 轻量 API 框架
