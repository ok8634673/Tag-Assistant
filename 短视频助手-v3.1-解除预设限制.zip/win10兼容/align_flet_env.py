"""
align_flet_env.py
Standalone: align flet + flet-desktop to a target version.
Supports Chinese paths. Auto-detects Python.

Usage:
  python align_flet_env.py              # auto-detect and align
  python align_flet_env.py 0.84.0     # force both to 0.84.0
  double-click align_flet_env.bat
"""
import subprocess
import sys
import os
import re
import json

TARGET_VERSION = "0.84.0"  # default target flet version

def find_pip(python_exe):
    for candidate in [
        python_exe.replace("python.exe", "pip.exe"),
        python_exe.replace("python.exe", "Scripts\\pip.exe"),
    ]:
        if os.path.exists(candidate):
            return candidate
    return None

def get_installed_version(pip_exe, pkg_name):
    try:
        out = subprocess.check_output(
            [pip_exe, "show", pkg_name],
            stderr=subprocess.DEVNULL,
            encoding="utf-8",
        )
        m = re.search(r"^Version:\s*(.+)$", out, re.MULTILINE)
        return m.group(1).strip() if m else None
    except Exception:
        return None

def run_pip(pip_exe, args):
    """Run pip, print output, return (ok, output_str)."""
    cmd = [pip_exe] + args
    print(f"  > {' '.join(cmd)}")
    try:
        result = subprocess.run(
            cmd,
            check=False,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
        )
        output = result.stdout + result.stderr
        for line in output.strip().splitlines():
            if line.strip():
                print(f"    {line}")
        return result.returncode == 0, output
    except Exception as e:
        print(f"    [ERROR] {e}")
        return False, str(e)

def main():
    # ---- Parse target version ----
    target = TARGET_VERSION
    if len(sys.argv) > 1:
        target = sys.argv[1].strip()
    print("=" * 50)
    print(f"  Align flet + flet-desktop -> {target}")
    print("=" * 50)

    python = sys.executable
    print(f"\n[Python] {python}")
    print(f"         version {sys.version.split()[0]}")

    pip = find_pip(python)
    if not pip or not os.path.exists(pip):
        print("[ERROR] Cannot find pip for this Python.")
        print("        Try manually: python -m pip install ...")
        input("\nPress Enter to exit...")
        sys.exit(1)
    print(f"[pip]    {pip}")

    # ---- Step 1: Align flet ----
    print(f"\n[Step 1/2] Checking flet...")
    flet_ver = get_installed_version(pip, "flet")
    if flet_ver:
        print(f"  Current flet:      {flet_ver}")
    else:
        print("  flet: (not installed)")

    if flet_ver == target:
        print(f"  [OK] flet already at {target}")
    else:
        print(f"  Installing flet=={target} ...")
        ok, _ = run_pip(pip, [
            "install", f"flet=={target}",
            "--force-reinstall", "--no-cache-dir",
        ])
        if not ok:
            print(f"\n[ERROR] Failed to install flet=={target}")
            print(f"        Check network or run manually:")
            print(f"        pip install flet=={target}")
            input("\nPress Enter to exit...")
            sys.exit(1)
        print(f"  [OK] flet=={target} installed.")

    # ---- Step 2: Align flet-desktop ----
    print(f"\n[Step 2/2] Checking flet-desktop...")
    fd_ver = get_installed_version(pip, "flet-desktop")
    if fd_ver:
        print(f"  Current flet-desktop: {fd_ver}")
    else:
        print("  flet-desktop: (not installed)")

    if fd_ver == target:
        print(f"  [OK] flet-desktop already at {target}")
    else:
        print(f"  Installing flet-desktop=={target} ...")
        ok, _ = run_pip(pip, [
            "install", f"flet-desktop=={target}",
            "--force-reinstall", "--no-cache-dir",
        ])
        if not ok:
            print(f"\n[ERROR] Failed to install flet-desktop=={target}")
            print(f"        Check network or run manually:")
            print(f"        pip install flet-desktop=={target}")
            input("\nPress Enter to exit...")
            sys.exit(1)
        print(f"  [OK] flet-desktop=={target} installed.")

    # ---- Verify ----
    print(f"\n{'=' * 50}")
    final_flet = get_installed_version(pip, "flet")
    final_fd = get_installed_version(pip, "flet-desktop")
    print(f"  flet:         {final_flet}")
    print(f"  flet-desktop: {final_fd}")
    if final_flet == target and final_fd == target:
        print(f"\n  [SUCCESS] Both aligned to {target}!")
    else:
        print(f"\n  [WARNING] Version mismatch after install.")
        print(f"           flet={final_flet}, flet-desktop={final_fd}")
    print(f"{'=' * 50}")
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
