@echo off
chcp 65001 >nul 2>&1
:: align_flet_env.bat
:: Launches align_flet_env.py with auto-detected Python
:: Usage: double-click, or pass version as argument:
::   align_flet_env.bat 0.84.0

set "PYTHON=py"
py --version >nul 2>&1 || set "PYTHON=python"
"%PYTHON%" "%~dp0align_flet_env.py" 0.84.0
if %errorlevel% neq 0 pause
